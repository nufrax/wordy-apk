import React, { useCallback, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, User } from 'firebase/auth';
import { getTodayDateKey } from './data/words';
import { auth, googleProvider } from './firebase';
import {
  applyXpGain,
  evaluateAchievements,
  incrementTaskStat,
  loadAndMergeCloudProfile,
  loadLocalProfile,
  recordTodayActivity,
  saveLocalProfile,
  ShopItem,
  syncProfileToCloud,
} from './services/playerService';
import { AvatarId, GameView, PlayerProfile, PlayerSettings, TaskDefinition, ThemeId } from './types/game';
import { soundFx } from './utils/sound';
import { HomeShell } from './components/HomeShell';
import { ClassicMode } from './components/ClassicMode';
import { DailyMode } from './components/DailyMode';
import { CircleMode } from './components/CircleMode';
import { MixedMode } from './components/MixedMode';
import { TogetherMode } from './components/TogetherMode';
import { ShopModal } from './components/ShopModal';
import { TasksModal } from './components/TasksModal';
import { SettingsModal } from './components/SettingsModal';
import { ProfileModal } from './components/ProfileModal';
import { StatsModal } from './components/StatsModal';

export default function App() {
  const [profile, setProfile] = useState<PlayerProfile>(() => loadLocalProfile());
  const [view, setView] = useState<GameView>('HOME');
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [shopOpen, setShopOpen] = useState(false);
  const [shopInitialTab, setShopInitialTab] = useState<'all' | 'hints' | 'powerups' | 'themes' | 'avatars'>('all');
  const [tasksOpen, setTasksOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [statsOpen, setStatsOpen] = useState(false);
  const [syncBusy, setSyncBusy] = useState(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState('');
  const [globalNotice, setGlobalNotice] = useState('');
  const notifiedBadgesRef = useRef<Set<string>>(new Set());

  // Sync dark mode class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (profile.settings.darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [profile.settings.darkMode]);

  // Persist local changes immediately
  useEffect(() => {
    saveLocalProfile(profile);
  }, [profile]);

  // Firebase Auth listener & automatic initial merge
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setAuthUser(user);
      if (user) {
        try {
          const merged = await loadAndMergeCloudProfile(loadLocalProfile());
          setProfile(merged);
        } catch (err) {
          console.error('Cloud profile merge error:', err);
        }
      }
    });
    return () => unsub();
  }, []);

  const showNotice = useCallback((msg: string) => {
    setGlobalNotice(msg);
    setTimeout(() => setGlobalNotice((prev) => (prev === msg ? '' : prev)), 2800);
  }, []);

  const updateProfileWithCloud = useCallback(
    (updater: (prev: PlayerProfile) => PlayerProfile) => {
      setProfile((prev) => {
        const rawNext = updater(prev);
        const { profile: evaluated, newlyUnlocked } = evaluateAchievements(rawNext);
        if (newlyUnlocked.length > 0) {
          const fresh = newlyUnlocked.filter((b) => !notifiedBadgesRef.current.has(b.id));
          if (fresh.length > 0) {
            fresh.forEach((b) => notifiedBadgesRef.current.add(b.id));
            const totalBonus = fresh.reduce((sum, b) => sum + b.rewardUzc, 0);
            const names = fresh.map((b) => b.titleUz).join(', ');
            queueMicrotask(() => {
              soundFx.victory(evaluated.settings.sound);
              showNotice(`Yutuq ochildi: ${names} (+${totalBonus} UZC)`);
            });
          }
        }
        if (auth.currentUser) {
          syncProfileToCloud(evaluated).catch((err) => {
            console.error('Background cloud sync error:', err);
          });
        }
        return evaluated;
      });
    },
    [showNotice]
  );

  const handleGoogleSignIn = useCallback(async () => {
    const result = await signInWithPopup(auth, googleProvider);
    if (result.user) {
      const merged = await loadAndMergeCloudProfile(profile);
      setProfile(merged);
      setSyncStatusMsg('Google hisobiga ulandi va saqlandi!');
    }
  }, [profile]);

  const handleCloudSave = async () => {
    setSyncBusy(true);
    setSyncStatusMsg('');
    try {
      if (!auth.currentUser) {
        await handleGoogleSignIn();
      } else {
        const synced = await syncProfileToCloud(profile);
        setProfile(synced);
        setSyncStatusMsg('Taraqqiyot bulutga muvaffaqiyatli saqlandi!');
      }
      soundFx.coin(profile.settings.sound);
    } catch (err) {
      setSyncStatusMsg(
        err instanceof Error ? err.message : 'Bulutga saqlashda xatolik yuz berdi'
      );
    } finally {
      setSyncBusy(false);
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
    setSyncStatusMsg('Hisobdan chiqildi');
  };

  const handleUseHint = useCallback((): boolean => {
    let used = false;
    setProfile((prev) => {
      if (prev.hints > 0) {
        used = true;
        const next = { ...prev, hints: prev.hints - 1 };
        if (auth.currentUser) syncProfileToCloud(next).catch(() => {});
        return next;
      }
      if (prev.uzc >= 25) {
        used = true;
        const { profile: evaluated } = evaluateAchievements({
          ...prev,
          uzc: prev.uzc - 25,
          stats: {
            ...prev.stats,
            totalUzcSpent: (prev.stats.totalUzcSpent || 0) + 25,
          },
        });
        if (auth.currentUser) syncProfileToCloud(evaluated).catch(() => {});
        queueMicrotask(() => showNotice('25 UZC evaziga maslahat ishlatildi'));
        return evaluated;
      }
      return prev;
    });
    return used;
  }, [showNotice]);

  const handleUsePowerup = useCallback(
    (key: 'revealLetter' | 'freezeTime' | 'scrambleRival'): boolean => {
      let ok = false;
      setProfile((prev) => {
        if ((prev.powerups[key] || 0) > 0) {
          ok = true;
          const next = {
            ...prev,
            powerups: { ...prev.powerups, [key]: prev.powerups[key] - 1 },
          };
          if (auth.currentUser) syncProfileToCloud(next).catch(() => {});
          return next;
        }
        if (prev.uzc >= 45) {
          ok = true;
          const { profile: evaluated } = evaluateAchievements({
            ...prev,
            uzc: prev.uzc - 45,
            stats: {
              ...prev.stats,
              totalUzcSpent: (prev.stats.totalUzcSpent || 0) + 45,
            },
          });
          if (auth.currentUser) syncProfileToCloud(evaluated).catch(() => {});
          queueMicrotask(() => showNotice('45 UZC evaziga kuchaytirgich ishlatildi'));
          return evaluated;
        }
        return prev;
      });
      return ok;
    },
    [showNotice]
  );

  const handleUseSkipWord = useCallback((): boolean => {
    let ok = false;
    setProfile((prev) => {
      const currentSkip = prev.powerups.skipWord || 0;
      if (currentSkip > 0) {
        ok = true;
        const next = {
          ...prev,
          powerups: { ...prev.powerups, skipWord: currentSkip - 1 },
        };
        if (auth.currentUser) syncProfileToCloud(next).catch(() => {});
        return next;
      }
      if (prev.uzc >= 40) {
        ok = true;
        const { profile: evaluated } = evaluateAchievements({
          ...prev,
          uzc: prev.uzc - 40,
          stats: {
            ...prev.stats,
            totalUzcSpent: (prev.stats.totalUzcSpent || 0) + 40,
          },
        });
        if (auth.currentUser) syncProfileToCloud(evaluated).catch(() => {});
        queueMicrotask(() => showNotice('40 UZC evaziga soʻz oʻtkazildi'));
        return evaluated;
      }
      return prev;
    });
    return ok;
  }, [showNotice]);

  // Mode completion callbacks
  const handleClassicComplete = (
    won: boolean,
    _attempts: number,
    rewardUzc: number,
    rewardXp: number
  ) => {
    updateProfileWithCloud((prev) => {
      const { level, xp } = applyXpGain(prev.level, prev.xp, rewardXp);
      const withStats = incrementTaskStat(prev, {
        classicPlayed: 1,
        classicWon: won ? 1 : 0,
      });
      const nextStreak = won ? (withStats.stats.currentWinStreak || 0) + 1 : 0;
      return recordTodayActivity({
        ...withStats,
        uzc: withStats.uzc + rewardUzc,
        level,
        xp,
        stats: {
          ...withStats.stats,
          classicStreak: won ? withStats.stats.classicStreak + 1 : 0,
          currentWinStreak: nextStreak,
          bestWinStreak: Math.max(withStats.stats.bestWinStreak || 0, nextStreak),
          totalUzcEarned: (withStats.stats.totalUzcEarned || 0) + rewardUzc,
        },
      });
    });
  };

  const handleSolveDailyWord = (wordIndex: number, rewardUzc: number, rewardXp: number) => {
    updateProfileWithCloud((prev) => {
      const today = getTodayDateKey();
      const existing = prev.dailyState.dateKey === today ? prev.dailyState.solvedIndices : [];
      if (existing.includes(wordIndex)) return prev;
      const { level, xp } = applyXpGain(prev.level, prev.xp, rewardXp);
      return recordTodayActivity({
        ...prev,
        uzc: prev.uzc + rewardUzc,
        level,
        xp,
        dailyState: {
          ...prev.dailyState,
          dateKey: today,
          solvedIndices: [...existing, wordIndex],
          claimedChest: prev.dailyState.claimedChest,
        },
        stats: {
          ...prev.stats,
          totalUzcEarned: (prev.stats.totalUzcEarned || 0) + rewardUzc,
        },
      });
    });
  };

  const handleClaimDailyChest = (rewardUzc: number, rewardXp: number) => {
    updateProfileWithCloud((prev) => {
      const { level, xp } = applyXpGain(prev.level, prev.xp, rewardXp);
      const withStats = incrementTaskStat(prev, { dailyCompleted: 1 });
      const nextStreak = (withStats.stats.currentWinStreak || 0) + 1;
      return recordTodayActivity({
        ...withStats,
        uzc: withStats.uzc + rewardUzc,
        level,
        xp,
        dailyState: {
          ...withStats.dailyState,
          claimedChest: true,
        },
        stats: {
          ...withStats.stats,
          currentWinStreak: nextStreak,
          bestWinStreak: Math.max(withStats.stats.bestWinStreak || 0, nextStreak),
          totalUzcEarned: (withStats.stats.totalUzcEarned || 0) + rewardUzc,
        },
      });
    });
  };

  const handleCircleFoundWord = (rewardUzc: number, rewardXp: number, isTargetWord: boolean) => {
    updateProfileWithCloud((prev) => {
      const { level, xp } = applyXpGain(prev.level, prev.xp, rewardXp);
      const base = isTargetWord ? incrementTaskStat(prev, { circleWordsFound: 1 }) : prev;
      return recordTodayActivity({
        ...base,
        uzc: base.uzc + rewardUzc,
        level,
        xp,
        stats: {
          ...base.stats,
          totalUzcEarned: (base.stats.totalUzcEarned || 0) + rewardUzc,
        },
      });
    });
  };

  const handleCircleCompleteLevel = (nextLevel: number, bonusUzc: number, bonusXp: number) => {
    updateProfileWithCloud((prev) => {
      const { level, xp } = applyXpGain(prev.level, prev.xp, bonusXp);
      return recordTodayActivity({
        ...prev,
        uzc: prev.uzc + bonusUzc,
        level,
        xp,
        stats: {
          ...prev.stats,
          circleLevel: nextLevel,
          totalUzcEarned: (prev.stats.totalUzcEarned || 0) + bonusUzc,
        },
      });
    });
  };

  const handleMixedSolve = (rewardUzc: number, rewardXp: number) => {
    updateProfileWithCloud((prev) => {
      const { level, xp } = applyXpGain(prev.level, prev.xp, rewardXp);
      const withStats = incrementTaskStat(prev, { mixedSolved: 1 });
      return recordTodayActivity({
        ...withStats,
        uzc: withStats.uzc + rewardUzc,
        level,
        xp,
        stats: {
          ...withStats.stats,
          totalUzcEarned: (withStats.stats.totalUzcEarned || 0) + rewardUzc,
        },
      });
    });
  };

  const handleDuelFinish = (won: boolean, rewardUzc: number, rewardXp: number) => {
    updateProfileWithCloud((prev) => {
      const { level, xp } = applyXpGain(prev.level, prev.xp, rewardXp);
      const withStats = incrementTaskStat(prev, {
        duelsPlayed: 1,
        duelsWon: won ? 1 : 0,
      });
      const nextStreak = won ? (withStats.stats.currentWinStreak || 0) + 1 : 0;
      return recordTodayActivity({
        ...withStats,
        uzc: withStats.uzc + rewardUzc,
        level,
        xp,
        stats: {
          ...withStats.stats,
          currentWinStreak: nextStreak,
          bestWinStreak: Math.max(withStats.stats.bestWinStreak || 0, nextStreak),
          totalUzcEarned: (withStats.stats.totalUzcEarned || 0) + rewardUzc,
        },
      });
    });
  };

  // Shop & Tasks handlers
  const handleClaimFreeCoins = () => {
    const today = getTodayDateKey();
    if (profile.lastFreeCoinDate === today) return;
    soundFx.coin(profile.settings.sound);
    updateProfileWithCloud((prev) =>
      recordTodayActivity({
        ...prev,
        uzc: prev.uzc + 50,
        lastFreeCoinDate: today,
        stats: {
          ...prev.stats,
          totalUzcEarned: (prev.stats.totalUzcEarned || 0) + 50,
        },
      })
    );
    showNotice('+50 UZC kunlik sovgʻa olindi!');
  };

  const handleBuyShopItem = (item: ShopItem) => {
    if (profile.uzc < item.priceUzc) return;
    soundFx.coin(profile.settings.sound);
    updateProfileWithCloud((prev) => {
      if (prev.uzc < item.priceUzc) return prev;
      const next: PlayerProfile = {
        ...prev,
        uzc: prev.uzc - item.priceUzc,
        stats: {
          ...prev.stats,
          totalUzcSpent: (prev.stats.totalUzcSpent || 0) + item.priceUzc,
        },
      };
      if (item.powerupKey && item.amount) {
        next.powerups = {
          ...prev.powerups,
          [item.powerupKey]: (prev.powerups[item.powerupKey] || 0) + item.amount,
        };
      } else if (item.category === 'hints' && item.amount) {
        next.hints += item.amount;
      } else if (item.category === 'themes' && item.themeId) {
        next.ownedThemes = Array.from(new Set([...prev.ownedThemes, item.themeId]));
        next.activeTheme = item.themeId;
        next.settings = { ...prev.settings, blueTheme: item.themeId === 'blue' };
      } else if (item.category === 'avatars' && item.avatarId) {
        next.ownedAvatars = Array.from(new Set([...prev.ownedAvatars, item.avatarId]));
        next.avatarId = item.avatarId;
      }
      return next;
    });
    showNotice(`"${item.titleUz}" xarid qilindi!`);
  };

  const handleEquipTheme = (themeId: ThemeId) => {
    soundFx.key(profile.settings.sound);
    updateProfileWithCloud((prev) => ({
      ...prev,
      activeTheme: themeId,
      settings: { ...prev.settings, blueTheme: themeId === 'blue' },
    }));
  };

  const handleEquipAvatar = (avatarId: AvatarId) => {
    soundFx.key(profile.settings.sound);
    updateProfileWithCloud((prev) => ({ ...prev, avatarId }));
  };

  const handleClaimTask = (task: TaskDefinition) => {
    soundFx.victory(profile.settings.sound);
    updateProfileWithCloud((prev) => {
      const cur = prev.tasks[task.id];
      if (!cur || cur.claimed || cur.progress < task.target) return prev;
      const { level, xp } = applyXpGain(prev.level, prev.xp, task.rewardXp);
      return {
        ...prev,
        uzc: prev.uzc + task.rewardUzc,
        level,
        xp,
        stats: {
          ...prev.stats,
          totalUzcEarned: (prev.stats.totalUzcEarned || 0) + task.rewardUzc,
        },
        tasks: {
          ...prev.tasks,
          [task.id]: { ...cur, claimed: true },
        },
      };
    });
    showNotice(`+${task.rewardUzc} UZC mukofot olindi!`);
  };

  const handleToggleSetting = (key: keyof PlayerSettings) => {
    soundFx.key(key === 'sound' ? !profile.settings.sound : profile.settings.sound);
    updateProfileWithCloud((prev) => {
      const nextVal = !prev.settings[key];
      const nextSettings = { ...prev.settings, [key]: nextVal };
      return {
        ...prev,
        activeTheme:
          key === 'blueTheme' ? (nextVal ? 'blue' : 'sunset') : prev.activeTheme,
        settings: nextSettings,
      };
    });
  };

  const handleSelectMode = (mode: GameView) => {
    soundFx.key(profile.settings.sound);
    setView(mode);
  };

  return (
    <div className="min-h-screen w-full relative">
      {globalNotice && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[60] px-4 py-2 rounded-2xl bg-slate-900/95 border border-amber-400/50 text-amber-200 text-xs font-bold shadow-xl pointer-events-none">
          {globalNotice}
        </div>
      )}

      {view === 'HOME' && (
        <HomeShell
          profile={profile}
          onSelectMode={handleSelectMode}
          onOpenShop={() => {
            setShopInitialTab('all');
            setShopOpen(true);
          }}
          onOpenStats={() => setStatsOpen(true)}
          onOpenSettings={() => setSettingsOpen(true)}
          onOpenTasks={() => setTasksOpen(true)}
          onOpenProfile={() => setProfileOpen(true)}
          onToggleSound={() => handleToggleSetting('sound')}
        />
      )}

      {view === 'CLASSIC' && (
        <ClassicMode
          profile={profile}
          onBack={() => setView('HOME')}
          onUseHint={handleUseHint}
          onUseSkipWord={handleUseSkipWord}
          onCompleteGame={handleClassicComplete}
        />
      )}

      {view === 'DAILY' && (
        <DailyMode
          profile={profile}
          onBack={() => setView('HOME')}
          onSolveDailyWord={handleSolveDailyWord}
          onClaimDailyChest={handleClaimDailyChest}
        />
      )}

      {view === 'CIRCLE' && (
        <CircleMode
          profile={profile}
          onBack={() => setView('HOME')}
          onUseHint={handleUseHint}
          onFoundWord={handleCircleFoundWord}
          onCompleteLevel={handleCircleCompleteLevel}
        />
      )}

      {view === 'MIXED' && (
        <MixedMode
          profile={profile}
          onBack={() => setView('HOME')}
          onUseHint={handleUseHint}
          onUseSkipWord={handleUseSkipWord}
          onSolveMixed={handleMixedSolve}
        />
      )}

      {view === 'TOGETHER' && (
        <TogetherMode
          profile={profile}
          isSignedIn={Boolean(authUser)}
          onSignIn={handleGoogleSignIn}
          onBack={() => setView('HOME')}
          onUsePowerup={handleUsePowerup}
          onFinishDuel={handleDuelFinish}
        />
      )}

      <ShopModal
        open={shopOpen}
        profile={profile}
        initialTab={shopInitialTab}
        onClose={() => setShopOpen(false)}
        onClaimFreeCoins={handleClaimFreeCoins}
        onBuyItem={handleBuyShopItem}
        onEquipTheme={handleEquipTheme}
        onEquipAvatar={handleEquipAvatar}
      />

      <TasksModal
        open={tasksOpen}
        profile={profile}
        onClose={() => setTasksOpen(false)}
        onClaimTask={handleClaimTask}
      />

      <SettingsModal
        open={settingsOpen}
        profile={profile}
        isSignedIn={Boolean(authUser)}
        userEmail={authUser?.email}
        syncBusy={syncBusy}
        syncStatusMsg={syncStatusMsg}
        onClose={() => setSettingsOpen(false)}
        onToggleSetting={handleToggleSetting}
        onUpdateName={(name) => updateProfileWithCloud((p) => ({ ...p, displayName: name }))}
        onCloudSave={handleCloudSave}
        onSignOut={handleSignOut}
      />

      <ProfileModal
        open={profileOpen}
        profile={profile}
        onClose={() => setProfileOpen(false)}
        onOpenAvatarShop={() => {
          setShopInitialTab('avatars');
          setShopOpen(true);
        }}
      />

      <StatsModal
        open={statsOpen}
        profile={profile}
        onClose={() => setStatsOpen(false)}
        onOpenProfile={() => setProfileOpen(true)}
      />
    </div>
  );
}
