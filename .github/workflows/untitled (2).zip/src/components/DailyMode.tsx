import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertCircle, ArrowLeft, CheckCircle2, Gift, Calendar, Play } from 'lucide-react';
import {
  evaluateWordleGuess,
  getDailyFiveWords,
  getTodayDateKey,
  WORDS_5_VALID,
} from '../data/words';
import { LetterState, PlayerProfile, VictoryReward } from '../types/game';
import { soundFx, triggerHaptic } from '../utils/sound';
import { UzcCoinIcon } from './GameIcons';
import { WordKeyboard } from './WordKeyboard';
import { VictoryModal } from './VictoryModal';

interface DailyModeProps {
  profile: PlayerProfile;
  onBack: () => void;
  onSolveDailyWord: (wordIndex: number, rewardUzc: number, rewardXp: number) => void;
  onClaimDailyChest: (rewardUzc: number, rewardXp: number) => void;
}

const MAX_ATTEMPTS = 6;
const WORD_LEN = 5;

export const DailyMode: React.FC<DailyModeProps> = ({
  profile,
  onBack,
  onSolveDailyWord,
  onClaimDailyChest,
}) => {
  const todayKey = getTodayDateKey();
  const dailyWords = useMemo(() => getDailyFiveWords(todayKey), [todayKey]);

  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [guesses, setGuesses] = useState<string[]>([]);
  const [currentGuess, setCurrentGuess] = useState<string>('');
  const [shakeRow, setShakeRow] = useState<boolean>(false);
  const [statusMsg, setStatusMsg] = useState<string>('');
  const [victoryReward, setVictoryReward] = useState<VictoryReward | null>(null);

  const solvedSet = useMemo(
    () => new Set(profile.dailyState.solvedIndices),
    [profile.dailyState.solvedIndices]
  );

  const allSolved = solvedSet.size >= 5;

  const activeTarget = activeIndex !== null ? dailyWords[activeIndex] : '';

  const isInvalidTypedWord = useMemo(() => {
    if (activeIndex === null || currentGuess.length !== WORD_LEN) return false;
    return !WORDS_5_VALID.has(currentGuess);
  }, [activeIndex, currentGuess]);

  const keyStates = useMemo(() => {
    const map: Record<string, LetterState> = {};
    if (!activeTarget) return map;
    const rank: Record<LetterState, number> = {
      empty: 0,
      tbd: 1,
      absent: 2,
      present: 3,
      correct: 4,
    };
    guesses.forEach((guess) => {
      const evals = evaluateWordleGuess(guess, activeTarget);
      guess.split('').forEach((ch, idx) => {
        const next = evals[idx];
        if (!map[ch] || rank[next] > rank[map[ch]]) {
          map[ch] = next;
        }
      });
    });
    return map;
  }, [guesses, activeTarget]);

  const showToast = useCallback((msg: string) => {
    setStatusMsg(msg);
    setTimeout(() => setStatusMsg((prev) => (prev === msg ? '' : prev)), 2200);
  }, []);

  const openWordPuzzle = (idx: number) => {
    if (solvedSet.has(idx)) return;
    setActiveIndex(idx);
    setGuesses([]);
    setCurrentGuess('');
    setStatusMsg('');
  };

  const handleKey = useCallback(
    (letter: string) => {
      if (activeIndex === null || currentGuess.length >= WORD_LEN) return;
      soundFx.key(profile.settings.sound);
      triggerHaptic(profile.settings.vibration, 10);
      setCurrentGuess((prev) => prev + letter);
    },
    [activeIndex, currentGuess.length, profile.settings.sound, profile.settings.vibration]
  );

  const handleBackspace = useCallback(() => {
    if (activeIndex === null || currentGuess.length === 0) return;
    soundFx.delete(profile.settings.sound);
    setCurrentGuess((prev) => prev.slice(0, -1));
  }, [activeIndex, currentGuess.length, profile.settings.sound]);

  const handleEnter = useCallback(() => {
    if (activeIndex === null) return;
    if (currentGuess.length < WORD_LEN) {
      soundFx.error(profile.settings.sound);
      setShakeRow(true);
      setTimeout(() => setShakeRow(false), 350);
      showToast('5 ta harf kiriting!');
      return;
    }
    if (!WORDS_5_VALID.has(currentGuess)) {
      soundFx.error(profile.settings.sound);
      setShakeRow(true);
      setTimeout(() => setShakeRow(false), 350);
      return;
    }

    const nextGuesses = [...guesses, currentGuess];
    setGuesses(nextGuesses);
    setCurrentGuess('');
    for (let i = 0; i < WORD_LEN; i++) {
      soundFx.flip(profile.settings.sound, i);
    }

    if (currentGuess === activeTarget) {
      const idxSolved = activeIndex;
      setTimeout(() => {
        soundFx.match(profile.settings.sound);
        onSolveDailyWord(idxSolved, 30, 25);
        setActiveIndex(null);
        setGuesses([]);
        setCurrentGuess('');
      }, 450);
    } else if (nextGuesses.length >= MAX_ATTEMPTS) {
      setTimeout(() => {
        soundFx.error(profile.settings.sound);
        showToast(`Soʻz "${activeTarget}" edi — qayta urinib koʻring!`);
        setGuesses([]);
        setCurrentGuess('');
      }, 500);
    }
  }, [
    activeIndex,
    activeTarget,
    currentGuess,
    guesses,
    onSolveDailyWord,
    profile.settings.sound,
    showToast,
  ]);

  useEffect(() => {
    if (activeIndex === null) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key === 'Enter') {
        e.preventDefault();
        handleEnter();
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (/^[a-zA-Z]$/.test(e.key)) {
        e.preventDefault();
        handleKey(e.key.toUpperCase());
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [activeIndex, handleBackspace, handleEnter, handleKey]);

  const handleOpenChest = () => {
    if (!allSolved || profile.dailyState.claimedChest) return;
    soundFx.victory(profile.settings.sound);
    triggerHaptic(profile.settings.vibration, [40, 40, 70]);
    onClaimDailyChest(150, 100);
    setVictoryReward({
      titleUz: 'Kunlik Gʻalaba!',
      subtitleUz: 'Bugungi barcha 5 ta soʻzni muvaffaqiyatli topdingiz!',
      uzc: 150,
      xp: 100,
      isWin: true,
    });
  };

  if (activeIndex !== null) {
    return (
      <div className="min-h-[100dvh] w-full flex flex-col justify-between bg-gradient-to-b from-orange-500 via-amber-500 to-orange-600 dark:from-slate-900 dark:via-slate-950 dark:to-black text-white">
        <header className="w-full max-w-lg mx-auto px-4 pt-4 pb-2 flex items-center justify-between">
          <button
            type="button"
            onClick={() => setActiveIndex(null)}
            className="w-10 h-10 rounded-xl bg-black/20 hover:bg-black/30 border border-white/20 flex items-center justify-center cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="text-center">
            <h1 className="font-display font-bold text-xl tracking-wide drop-shadow-sm">
              KUNLIK · {activeIndex + 1}-SOʻZ
            </h1>
          </div>
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-black/25 border border-white/20">
            <UzcCoinIcon className="w-4 h-4" />
            <span className="font-mono-num text-sm font-bold text-amber-200">{profile.uzc}</span>
          </div>
        </header>

        <div className="h-7 flex items-center justify-center px-3">
          {isInvalidTypedWord ? (
            <div className="px-3.5 py-1 rounded-xl bg-rose-600 text-white border border-rose-300 text-xs font-bold shadow-lg flex items-center gap-1.5 animate-wordy-pop">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              Lugʻatda bunday soʻz mavjud emas
            </div>
          ) : statusMsg ? (
            <div className="px-4 py-1 rounded-xl bg-slate-900/95 border border-amber-400/50 text-amber-200 text-xs font-bold shadow-lg">
              {statusMsg}
            </div>
          ) : null}
        </div>

        <main className="flex-1 flex flex-col items-center justify-center px-3 py-2">
          <div className="grid grid-rows-6 gap-2 w-full max-w-[300px] sm:max-w-[330px]">
            {Array.from({ length: MAX_ATTEMPTS }).map((_, rowIdx) => {
              const isSubmitted = rowIdx < guesses.length;
              const isCurrent = rowIdx === guesses.length;
              const word = isSubmitted ? guesses[rowIdx] : isCurrent ? currentGuess : '';
              const evals = isSubmitted ? evaluateWordleGuess(word, activeTarget) : [];

              return (
                <div
                  key={rowIdx}
                  className={`grid grid-cols-5 gap-2 ${
                    isCurrent && shakeRow ? 'animate-wordy-shake' : ''
                  }`}
                >
                  {Array.from({ length: WORD_LEN }).map((__, colIdx) => {
                    const char = word[colIdx] || '';
                    const state = isSubmitted ? evals[colIdx] : char ? 'tbd' : 'empty';
                    let tileCls =
                      'bg-white/20 dark:bg-slate-800/75 border-2 border-white/40 dark:border-slate-600 text-white';
                    if (state === 'tbd') {
                      tileCls = isInvalidTypedWord
                        ? 'bg-rose-100 text-rose-700 border-2 border-rose-400 border-b-4 border-b-rose-500 animate-wordy-pop shadow-md'
                        : 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white border-2 border-white dark:border-amber-300 border-b-4 border-b-slate-300 dark:border-b-slate-900 animate-wordy-pop shadow-md';
                    }
                    if (state === 'correct')
                      tileCls =
                        'bg-emerald-500 border-2 border-emerald-400 border-b-4 border-b-emerald-700 text-white animate-wordy-flip shadow-md';
                    if (state === 'present')
                      tileCls =
                        'bg-amber-300 border-2 border-amber-200 border-b-4 border-b-amber-600 text-amber-950 animate-wordy-flip shadow-md';
                    if (state === 'absent')
                      tileCls =
                        'bg-slate-700/90 border-2 border-slate-600 border-b-4 border-b-slate-900 text-white/85 animate-wordy-flip';

                    return (
                      <div
                        key={colIdx}
                        style={isSubmitted ? { animationDelay: `${colIdx * 60}ms` } : undefined}
                        className={`aspect-square rounded-2xl flex items-center justify-center font-display font-bold text-2xl sm:text-3xl ${tileCls}`}
                      >
                        {char}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </main>

        <footer className="w-full px-2 sm:px-4 pb-5 pt-2">
          <WordKeyboard
            keyStates={keyStates}
            onKey={handleKey}
            onEnter={handleEnter}
            onBackspace={handleBackspace}
            invalidWord={isInvalidTypedWord}
          />
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] w-full flex flex-col bg-gradient-to-b from-orange-500 via-amber-500 to-orange-600 dark:from-slate-900 dark:via-slate-950 dark:to-black text-white">
      <header className="w-full max-w-md mx-auto px-3.5 pt-4 pb-2 flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          aria-label="Orqaga"
          className="w-10 h-10 rounded-xl bg-black/20 hover:bg-black/30 flex items-center justify-center cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="text-center">
          <div className="flex items-center justify-center gap-2 font-display font-bold text-xl">
            <Calendar className="w-5 h-5 text-amber-200" />
            KUNLIK
          </div>
          <p className="text-[11px] font-medium text-amber-100">Bugungi kun · {todayKey}</p>
        </div>

        <div className="w-10 h-10 rounded-xl bg-black/20 flex items-center justify-center">
          <Gift className="w-5 h-5 text-amber-200" />
        </div>
      </header>

      <main className="flex-1 w-full max-w-md mx-auto px-3.5 pb-6 flex flex-col justify-center">
        {/* Coin Banner */}
        <div className="rounded-3xl bg-black/20 dark:bg-white/5 border border-white/20 p-5 mb-5 flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-300/20 flex items-center justify-center shrink-0">
            <UzcCoinIcon className="w-11 h-11" />
          </div>
          <div>
            <h2 className="font-display font-bold text-lg leading-snug">
              5 ta soʻz toping va mukofot oling!
            </h2>
            <p className="text-xs text-amber-100/90 mt-0.5">
              Har bir soʻz uchun +30 UZC, barchasi uchun +150 UZC bonus
            </p>
          </div>
        </div>

        {/* 5 Daily Word Cards */}
        <div className="flex flex-col gap-3 mb-6">
          {dailyWords.map((word, idx) => {
            const isSolved = solvedSet.has(idx);
            const isNext = !isSolved && idx === solvedSet.size;
            return (
              <button
                key={idx}
                type="button"
                onClick={() => openWordPuzzle(idx)}
                disabled={isSolved}
                className={`w-full rounded-2xl px-4 py-3.5 flex items-center justify-between border-b-4 transition-transform text-left ${
                  isSolved
                    ? 'bg-amber-100 dark:bg-slate-800 text-slate-900 dark:text-white border-amber-300 dark:border-slate-700'
                    : isNext
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white border-amber-400 hover:scale-[1.01] cursor-pointer shadow-lg'
                    : 'bg-amber-50/90 dark:bg-slate-800/80 text-slate-800 dark:text-slate-200 border-amber-300/80 dark:border-slate-700 hover:bg-white cursor-pointer'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <span className="w-8 h-8 rounded-full bg-amber-900/85 text-amber-100 font-mono-num font-bold text-sm flex items-center justify-center shrink-0">
                    {idx + 1}
                  </span>
                  <div>
                    <div className="font-display font-bold text-lg tracking-wider">
                      {isSolved ? word : '• • • • •'}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {isSolved ? 'Topildi (+30 UZC)' : '5 harfli inglizcha soʻz'}
                    </div>
                  </div>
                </div>

                {isSolved ? (
                  <CheckCircle2 className="w-7 h-7 text-emerald-600 shrink-0" />
                ) : idx === 4 ? (
                  <div className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400 font-bold text-xs">
                    <Gift className="w-6 h-6" />
                  </div>
                ) : (
                  <span className="px-3 py-1.5 rounded-xl bg-amber-500 text-amber-950 font-bold text-xs flex items-center gap-1">
                    <Play className="w-3.5 h-3.5 fill-current" />
                    Topish
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Action Button */}
        {allSolved && !profile.dailyState.claimedChest ? (
          <button
            type="button"
            onClick={handleOpenChest}
            className="w-full py-4 rounded-2xl bg-gradient-to-b from-yellow-300 to-amber-500 text-amber-950 font-display font-bold text-lg border-b-4 border-amber-700 shadow-xl flex items-center justify-center gap-2 cursor-pointer animate-wordy-pop"
          >
            <Gift className="w-6 h-6" />
            Sovgʻa sandigʻini ochish (+150 UZC)
          </button>
        ) : allSolved && profile.dailyState.claimedChest ? (
          <div className="w-full py-4 rounded-2xl bg-emerald-700/90 border border-emerald-400/50 text-center font-bold text-sm">
            Bugungi barcha mukofotlar olindi! Ertaga yangi 5 ta soʻz chiqadi.
          </div>
        ) : (
          <button
            type="button"
            onClick={() => {
              const firstUnsolved = [0, 1, 2, 3, 4].find((i) => !solvedSet.has(i));
              if (firstUnsolved !== undefined) openWordPuzzle(firstUnsolved);
            }}
            className="w-full py-4 rounded-2xl bg-gradient-to-b from-yellow-300 to-amber-400 hover:from-yellow-200 hover:to-amber-300 text-amber-950 font-display font-bold text-lg border-b-4 border-amber-600 shadow-lg flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-current" />
            Oʻynash ({solvedSet.size}/5)
          </button>
        )}
      </main>

      <VictoryModal
        reward={victoryReward}
        onContinue={() => {
          setVictoryReward(null);
          onBack();
        }}
      />
    </div>
  );
};
