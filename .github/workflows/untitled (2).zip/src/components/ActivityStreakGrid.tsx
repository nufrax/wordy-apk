import React, { useState } from 'react';
import { CalendarDays, Flame } from 'lucide-react';
import { getTodayDateKey } from '../data/words';
import { calculateDayStreak } from '../services/playerService';

interface ActivityStreakGridProps {
  activityDays?: string[];
}

function addDaysKey(dateKey: string, deltaDays: number): string {
  const [y, m, d] = dateKey.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + deltaDays));
  const yy = dt.getUTCFullYear();
  const mm = String(dt.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(dt.getUTCDate()).padStart(2, '0');
  return `${yy}-${mm}-${dd}`;
}

const UZ_MONTHS = [
  'Yanvar',
  'Fevral',
  'Mart',
  'Aprel',
  'May',
  'Iyun',
  'Iyul',
  'Avgust',
  'Sentabr',
  'Oktabr',
  'Noyabr',
  'Dekabr',
];

function formatDateUz(dateKey: string): string {
  const [, m, d] = dateKey.split('-').map(Number);
  return `${d} ${UZ_MONTHS[(m - 1) % 12]}`;
}

export const ActivityStreakGrid: React.FC<ActivityStreakGridProps> = ({ activityDays }) => {
  const today = getTodayDateKey();
  const [selectedKey, setSelectedKey] = useState<string>(today);

  const { currentDayStreak, longestDayStreak, activeSet } = calculateDayStreak(activityDays);

  // Build exact set of dates belonging to the current ongoing streak
  const currentStreakSet = new Set<string>();
  const yesterday = addDaysKey(today, -1);
  let cursor = activeSet.has(today) ? today : activeSet.has(yesterday) ? yesterday : '';
  while (cursor && activeSet.has(cursor)) {
    currentStreakSet.add(cursor);
    cursor = addDaysKey(cursor, -1);
  }

  // Last 30 days: (today - 29) .. today
  const days30 = Array.from({ length: 30 }, (_, idx) => {
    const key = addDaysKey(today, idx - 29);
    const dayNum = Number(key.slice(8, 10));
    const isActive = activeSet.has(key);
    const prevActive = idx > 0 && activeSet.has(addDaysKey(key, -1));
    const nextActive = idx < 29 && activeSet.has(addDaysKey(key, 1));
    const inCurrentStreak = currentStreakSet.has(key);
    const isConsecutive = isActive && (prevActive || nextActive);
    const isToday = key === today;

    return {
      key,
      dayNum,
      isActive,
      prevActive,
      nextActive,
      inCurrentStreak,
      isConsecutive,
      isToday,
    };
  });

  const activeLast30Count = days30.filter((d) => d.isActive).length;
  const selectedDay = days30.find((d) => d.key === selectedKey) || days30[days30.length - 1];

  return (
    <section
      aria-label="Oxirgi 30 kunlik faollik"
      className="rounded-2xl bg-white dark:bg-slate-800/95 border-2 border-amber-300/80 dark:border-slate-700 p-3.5 sm:p-4 shadow-sm"
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-orange-100 dark:bg-orange-500/20 flex items-center justify-center text-orange-600 dark:text-orange-300 shrink-0">
            <CalendarDays className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-display font-bold text-sm sm:text-base leading-none">
              OXIRGI 30 KUNLIK FAOLLIK
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              Oxirgi 30 kunda {activeLast30Count} kun faol oʻynalgan
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="px-2.5 py-1 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 text-white font-mono-num text-xs font-bold flex items-center gap-1 shadow-sm">
            <Flame className="w-3.5 h-3.5 fill-current" />
            {currentDayStreak} kun seriya
          </span>
          <span className="px-2 py-1 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-mono-num text-[11px] font-bold">
            Rekord: {longestDayStreak}
          </span>
        </div>
      </div>

      {/* 30-Square Activity Grid (6x5 on mobile, 10x3 on sm+) */}
      <div className="grid grid-cols-6 sm:grid-cols-10 gap-1.5">
        {days30.map((cell) => {
          let squareClass =
            'bg-slate-100 dark:bg-slate-700/60 text-slate-400 dark:text-slate-500 border border-dashed border-slate-300/80 dark:border-slate-600';

          if (cell.inCurrentStreak) {
            squareClass =
              'bg-gradient-to-br from-orange-500 via-amber-500 to-yellow-400 text-white border-2 border-orange-300 shadow-[0_2px_10px_rgba(249,115,22,0.45)]';
          } else if (cell.isConsecutive) {
            squareClass =
              'bg-gradient-to-br from-teal-500 to-emerald-500 text-white border border-teal-300 shadow-sm';
          } else if (cell.isActive) {
            squareClass =
              'bg-emerald-500 text-white border border-emerald-400 shadow-sm';
          }

          const isSelected = selectedDay.key === cell.key;

          return (
            <button
              key={cell.key}
              type="button"
              onClick={() => setSelectedKey(cell.key)}
              title={`${formatDateUz(cell.key)} — ${
                cell.inCurrentStreak
                  ? 'Joriy seriya'
                  : cell.isConsecutive
                  ? 'Ketma-ket faol kun'
                  : cell.isActive
                  ? 'Faol kun'
                  : 'Oʻynalmagan'
              }`}
              className={`relative aspect-square rounded-lg flex flex-col items-center justify-center font-mono-num text-[11px] font-bold transition-transform cursor-pointer hover:scale-105 ${squareClass} ${
                cell.isToday
                  ? 'ring-2 ring-indigo-500 dark:ring-sky-400 ring-offset-1 ring-offset-white dark:ring-offset-slate-800'
                  : isSelected
                  ? 'ring-2 ring-slate-400/70'
                  : ''
              }`}
            >
              <span>{cell.dayNum}</span>
              {cell.inCurrentStreak && (
                <span className="w-1.5 h-1.5 rounded-full bg-white/95 mt-0.5" />
              )}
            </button>
          );
        })}
      </div>

      {/* Interactive Day Info + Legend */}
      <div className="mt-3 pt-2.5 border-t border-slate-200/80 dark:border-slate-700/80 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-[11px]">
        <div className="flex flex-wrap items-center gap-2.5 text-slate-600 dark:text-slate-300 font-semibold">
          <span className="inline-flex items-center gap-1">
            <span className="w-3 h-3 rounded bg-gradient-to-br from-orange-500 to-amber-400 inline-block" />
            Joriy seriya
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="w-3 h-3 rounded bg-teal-500 inline-block" />
            Ketma-ket
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="w-3 h-3 rounded bg-emerald-500 inline-block" />
            Faol kun
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="w-3 h-3 rounded border border-dashed border-slate-400 bg-slate-100 dark:bg-slate-700 inline-block" />
            Boʻsh
          </span>
        </div>

        <div className="font-semibold text-indigo-600 dark:text-sky-300">
          {formatDateUz(selectedDay.key)}:{' '}
          {selectedDay.inCurrentStreak
            ? 'Joriy seriya 🔥'
            : selectedDay.isConsecutive
            ? 'Ketma-ket faol'
            : selectedDay.isActive
            ? 'Faol kun'
            : 'Oʻynalmagan'}
        </div>
      </div>
    </section>
  );
};
