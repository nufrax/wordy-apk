import {
  doc,
  getDoc,
  onSnapshot,
  serverTimestamp,
  setDoc,
  Unsubscribe,
  updateDoc,
} from 'firebase/firestore';
import { getDuelWordsFromSeed } from '../data/words';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { AvatarId, DuelPlayerState, DuelRoom, DuelVariant } from '../types/game';

export const DUEL_VARIANT_META: Record<
  DuelVariant,
  {
    titleUz: string;
    subtitleUz: string;
    durationSeconds: number;
    durationLabelUz: string;
    totalRounds: number;
    maxPlayers: number;
    rewardWinUzc: number;
  }
> = {
  classic_duel: {
    titleUz: 'Classic Duel',
    subtitleUz: 'Oddiy va tezkor',
    durationSeconds: 120,
    durationLabelUz: '2 daqiqa',
    totalRounds: 5,
    maxPlayers: 2,
    rewardWinUzc: 120,
  },
  battle_duel: {
    titleUz: 'Battle Duel',
    subtitleUz: 'Strategik duel',
    durationSeconds: 180,
    durationLabelUz: '3 daqiqa',
    totalRounds: 6,
    maxPlayers: 2,
    rewardWinUzc: 180,
  },
  team_duel: {
    titleUz: 'Team Duel',
    subtitleUz: 'Jamoa bilan',
    durationSeconds: 180,
    durationLabelUz: '3 daqiqa',
    totalRounds: 10,
    maxPlayers: 4,
    rewardWinUzc: 220,
  },
};

export function generateInviteCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  for (let i = 0; i < 6; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

export interface DuelConfigOptions {
  wordLen?: 5 | 6;
  totalRounds?: number;
  durationSeconds?: number;
}

export async function createOnlineDuelRoom(
  variant: DuelVariant,
  playerName: string,
  avatarId: AvatarId,
  options?: DuelConfigOptions
): Promise<DuelRoom> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('Onlayn xona yaratish uchun avval Google orqali kiring.');
  }

  const meta = DUEL_VARIANT_META[variant];
  const wordLen: 5 | 6 = options?.wordLen === 6 ? 6 : 5;
  const totalRounds = Math.min(10, Math.max(1, Math.round(options?.totalRounds ?? meta.totalRounds)));
  const durationSeconds = Math.min(
    600,
    Math.max(60, Math.round(options?.durationSeconds ?? meta.durationSeconds))
  );

  const inviteCode = generateInviteCode();
  const words = getDuelWordsFromSeed(inviteCode, totalRounds, wordLen);
  const path = `duelRooms/${inviteCode}`;

  const initialPlayer: DuelPlayerState = {
    uid: user.uid,
    displayName: playerName.slice(0, 24) || 'Oʻyinchi',
    avatarId,
    team: 'blue',
    score: 0,
    roundIndex: 0,
    solvedCount: 0,
    finished: false,
  };

  const roomDoc = {
    inviteCode,
    hostId: user.uid,
    variant,
    status: 'waiting' as const,
    maxPlayers: meta.maxPlayers,
    totalRounds,
    durationSeconds,
    words,
    participantIds: [user.uid],
    playerStates: {
      [user.uid]: initialPlayer,
    },
    winnerTeam: '',
    startedAtMs: 0,
  };

  try {
    await setDoc(doc(db, 'duelRooms', inviteCode), {
      ...roomDoc,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return roomDoc;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function joinOnlineDuelRoom(
  codeRaw: string,
  playerName: string,
  avatarId: AvatarId
): Promise<DuelRoom> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('Onlayn xonaga qoʻshilish uchun avval Google orqali kiring.');
  }

  const code = codeRaw.trim().toUpperCase();
  if (!/^[A-Z0-9]{6}$/.test(code)) {
    throw new Error('Taklif kodi 6 ta harf va raqamdan iborat boʻlishi kerak.');
  }

  const path = `duelRooms/${code}`;
  const roomRef = doc(db, 'duelRooms', code);

  let snap;
  try {
    snap = await getDoc(roomRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }

  if (!snap.exists()) {
    throw new Error('Bunday taklif kodli xona topilmadi.');
  }

  const room = snap.data() as DuelRoom;
  if (room.participantIds.includes(user.uid)) {
    return room;
  }

  if (room.status !== 'waiting') {
    throw new Error('Bu duel allaqachon boshlangan yoki tugagan.');
  }

  if (room.participantIds.length >= room.maxPlayers) {
    throw new Error('Xona toʻlgan.');
  }

  const blueCount = Object.values(room.playerStates).filter((p) => p.team === 'blue').length;
  const redCount = Object.values(room.playerStates).filter((p) => p.team === 'red').length;
  const assignedTeam: 'blue' | 'red' =
    room.variant === 'team_duel' ? (redCount <= blueCount ? 'red' : 'blue') : 'red';

  const newPlayer: DuelPlayerState = {
    uid: user.uid,
    displayName: playerName.slice(0, 24) || 'Oʻyinchi',
    avatarId,
    team: assignedTeam,
    score: 0,
    roundIndex: 0,
    solvedCount: 0,
    finished: false,
  };

  const nextParticipants = [...room.participantIds, user.uid];
  const nextStates = {
    ...room.playerStates,
    [user.uid]: newPlayer,
  };

  try {
    await updateDoc(roomRef, {
      participantIds: nextParticipants,
      playerStates: nextStates,
      updatedAt: serverTimestamp(),
    });
    return {
      ...room,
      participantIds: nextParticipants,
      playerStates: nextStates,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function startOnlineDuelRoom(inviteCode: string): Promise<void> {
  const path = `duelRooms/${inviteCode}`;
  try {
    await updateDoc(doc(db, 'duelRooms', inviteCode), {
      status: 'active',
      startedAtMs: Date.now(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function updateOnlineDuelProgress(
  room: DuelRoom,
  playerState: DuelPlayerState,
  extraStates?: Record<string, DuelPlayerState>,
  finishInfo?: { status: 'finished'; winnerTeam: string }
): Promise<void> {
  const path = `duelRooms/${room.inviteCode}`;
  const mergedStates = {
    ...room.playerStates,
    ...(extraStates || {}),
    [playerState.uid]: playerState,
  };

  const payload: Record<string, unknown> = {
    playerStates: mergedStates,
    updatedAt: serverTimestamp(),
  };

  if (finishInfo) {
    payload.status = finishInfo.status;
    payload.winnerTeam = finishInfo.winnerTeam;
  }

  try {
    await updateDoc(doc(db, 'duelRooms', room.inviteCode), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export function subscribeToDuelRoom(
  inviteCode: string,
  onUpdate: (room: DuelRoom) => void
): Unsubscribe {
  const path = `duelRooms/${inviteCode}`;
  return onSnapshot(
    doc(db, 'duelRooms', inviteCode),
    (snapshot) => {
      if (snapshot.exists()) {
        onUpdate(snapshot.data() as DuelRoom);
      }
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
}
