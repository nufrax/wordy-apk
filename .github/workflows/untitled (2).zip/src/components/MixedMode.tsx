import React, { useCallback, useEffect, useState } from 'react';
import { ArrowLeft, Lightbulb, Shuffle, SkipForward, Flame } from 'lucide-react';
import { MIXED_PUZZLES, scrambleWord } from '../data/words';
import { PlayerProfile, VictoryReward } from '../types/game';
import { soundFx, triggerHaptic } from '../utils/sound';
import { UzcCoinIcon } from './GameIcons';
import { VictoryModal } from './VictoryModal';

interface MixedModeProps {
  profile: PlayerProfile;
  onBack: () => void;
  onUseHint: () => boolean;
  onUseSkipWord: () => boolean;
  onSolveMixed: (rewardUzc: number, rewardXp: number) => void;
}

export const MixedMode: React.FC<MixedModeProps> = ({
  profile,
  onBack,
  onUseHint,
  onUseSkipWord,
  onSolveMixed,
}) => {
  const [puzzleIdx, setPuzzleIdx] = useState<number>(() =>
    Math.floor(Math.random() * MIXED_PUZZLES.length)
  );
  const puzzle = MIXED_PUZZLES[puzzleIdx];

  const [pool, setPool] = useState<string[]>(() => scrambleWord(puzzle.word));
  const [slots, setSlots] = useState<(number | null)[]>(() =>
    Array(puzzle.word.length).fill(null)
  );
  const [lockedIndices, setLockedIndices] = useState<number[]>([]);
  const [streak, setStreak] = useState<number>(0);
  const [shake, setShake] = useState<boolean>(false);
  const [toast, setToast] = useState<string>('');
  const [victoryReward, setVictoryReward] = useState<VictoryReward | null>(null);

  const loadPuzzle = useCallback((nextIdx: number) => {
    const next = MIXED_PUZZLES[nextIdx % MIXED_PUZZLES.length];
    setPuzzleIdx(nextIdx % MIXED_PUZZLES.length);
    setPool(scrambleWord(next.word));
    setSlots(Array(next.word.length).fill(null));
    setLockedIndices([]);
    setVictoryReward(null);
    setToast('');
  }, []);

  const showStatus = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast((prev) => (prev === msg ? '' : prev)), 2000);
  }, []);

  const usedPoolIndices = new Set(slots.filter((v): v is number => v !== null));

  const checkSolved = useCallback(
    (nextSlots: (number | null)[]) => {
      if (nextSlots.some((v) => v === null)) return;
      const formed = nextSlots.map((idx) => pool[idx!]).join('');
      if (puzzle.acceptedAnagrams.includes(formed)) {
        const nextStreak = streak + 1;
        setStreak(nextStreak);
        const rewardUzc = 35 + Math.min(35, nextStreak * 5);
        const rewardXp = 30 + Math.min(30, nextStreak * 4);
        soundFx.victory(profile.settings.sound);
        triggerHaptic(profile.settings.vibration, [30, 30, 50]);
        onSolveMixed(rewardUzc, rewardXp);
        setVictoryReward({
          titleUz: 'Toʻgʻri topildi!',
          subtitleUz: `"${formed}" soʻzini muvaffaqiyatli tuzdingiz! Seriya: ${nextStreak}`,
          uzc: rewardUzc,
          xp: rewardXp,
          isWin: true,
        });
      } else {
        soundFx.error(profile.settings.sound);
        triggerHaptic(profile.settings.vibration, [25, 30, 25]);
        setShake(true);
        setTimeout(() => {
          setShake(false);
          setSlots((prev) => prev.map((v, i) => (lockedIndices.includes(i) ? v : null)));
        }, 380);
        showStatus('Tartib notoʻgʻri, qayta urinib koʻring!');
      }
    },
    [
      lockedIndices,
      onSolveMixed,
      pool,
      profile.settings.sound,
      profile.settings.vibration,
      puzzle.acceptedAnagrams,
      showStatus,
      streak,
    ]
  );

  const handleTapPool = useCallback(
    (poolIdx: number) => {
      if (usedPoolIndices.has(poolIdx) || victoryReward) return;
      const emptySlot = slots.findIndex((v) => v === null);
      if (emptySlot === -1) return;

      soundFx.key(profile.settings.sound);
      triggerHaptic(profile.settings.vibration, 10);
      const nextSlots = [...slots];
      nextSlots[emptySlot] = poolIdx;
      setSlots(nextSlots);
      checkSolved(nextSlots);
    },
    [
      checkSolved,
      profile.settings.sound,
      profile.settings.vibration,
      slots,
      usedPoolIndices,
      victoryReward,
    ]
  );

  const handleTapSlot = useCallback(
    (slotIdx: number) => {
      if (lockedIndices.includes(slotIdx) || slots[slotIdx] === null || victoryReward) return;
      soundFx.delete(profile.settings.sound);
      const nextSlots = [...slots];
      nextSlots[slotIdx] = null;
      setSlots(nextSlots);
    },
    [lockedIndices, profile.settings.sound, slots, victoryReward]
  );

  const handleShuffle = () => {
    soundFx.flip(profile.settings.sound, 0);
    setSlots(Array(puzzle.word.length).fill(null));
    setLockedIndices([]);
    setPool(scrambleWord(puzzle.word));
  };

  const handleSkipPuzzle = () => {
    if (!onUseSkipWord()) {
      soundFx.error(profile.settings.sound);
      showStatus("Oʻtkazish boosteri yoʻq (yoki 40 UZC kerak)");
      return;
    }
    soundFx.powerup(profile.settings.sound);
    triggerHaptic(profile.settings.vibration, 20);
    loadPuzzle(puzzleIdx + 1);
    showStatus('Keyingi soʻzga oʻtildi!');
  };

  const handleHint = () => {
    const targetWord = puzzle.word;
    const emptyIdx = slots.findIndex((val, idx) => {
      if (val === null) return true;
      return pool[val] !== targetWord[idx];
    });
    if (emptyIdx === -1) return;

    if (!onUseHint()) {
      showStatus('Maslahat tugagan! Doʻkondan UZC ga oling');
      return;
    }

    const neededChar = targetWord[emptyIdx];
    const lockedPoolSet = new Set(lockedIndices.map((s) => slots[s]));
    const matchingPoolIdx = pool.findIndex(
      (ch, idx) => ch === neededChar && !lockedPoolSet.has(idx)
    );

    if (matchingPoolIdx === -1) return;

    soundFx.coin(profile.settings.sound);
    const nextSlots = slots.map((val) => (val === matchingPoolIdx ? null : val));
    nextSlots[emptyIdx] = matchingPoolIdx;
    setSlots(nextSlots);
    setLockedIndices((prev) => Array.from(new Set([...prev, emptyIdx])));
    checkSolved(nextSlots);
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (victoryReward || e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key === 'Backspace') {
        e.preventDefault();
        for (let i = slots.length - 1; i >= 0; i--) {
          if (slots[i] !== null && !lockedIndices.includes(i)) {
            handleTapSlot(i);
            break;
          }
        }
      } else if (/^[a-zA-Z]$/.test(e.key)) {
        const ch = e.key.toUpperCase();
        const availableIdx = pool.findIndex((p, idx) => p === ch && !usedPoolIndices.has(idx));
        if (availableIdx !== -1) {
          handleTapPool(availableIdx);
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleTapPool, handleTapSlot, lockedIndices, pool, slots, usedPoolIndices, victoryReward]);

  return (
    <div className="min-h-[100dvh] w-full flex flex-col justify-between bg-gradient-to-b from-purple-600 via-violet-700 to-indigo-800 dark:from-slate-900 dark:via-slate-950 dark:to-black text-white">
      <header className="w-full max-w-lg mx-auto px-3.5 pt-3.5 pb-1 flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          aria-label="Orqaga"
          className="w-10 h-10 rounded-xl bg-black/20 hover:bg-black/30 border border-white/20 flex items-center justify-center cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="text-center">
          <h1 className="font-display font-bold text-xl tracking-wide drop-shadow-sm">MIXED</h1>
          <p className="text-[11px] text-purple-100">{puzzle.word.length} harfli anagramma</p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-black/25 text-xs font-bold text-amber-200">
            <Flame className="w-3.5 h-3.5 text-orange-300" />
            <span className="font-mono-num">{streak}</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/25 border border-white/20">
            <UzcCoinIcon className="w-4 h-4" />
            <span className="font-mono-num text-sm font-bold text-amber-200">{profile.uzc}</span>
          </div>
        </div>
      </header>

      <main className="flex-1 w-full max-w-xl mx-auto px-4 pb-8 flex flex-col items-center justify-center gap-7">
        <div className="h-7 flex items-center justify-center">
          {toast && (
            <div className="px-4 py-1 rounded-xl bg-slate-950/90 border border-amber-400/40 text-amber-200 text-xs font-bold shadow-lg">
              {toast}
            </div>
          )}
        </div>

        {/* Scrambled Pool Tiles */}
        <div className="flex flex-wrap justify-center gap-2.5 sm:gap-3">
          {pool.map((letter, idx) => {
            const isUsed = usedPoolIndices.has(idx);
            return (
              <button
                key={idx}
                type="button"
                disabled={isUsed}
                onClick={() => handleTapPool(idx)}
                className={`w-13 h-14 sm:w-15 sm:h-16 rounded-2xl font-display font-bold text-2xl sm:text-3xl border-b-4 transition-transform flex items-center justify-center ${
                  isUsed
                    ? 'bg-purple-950/35 border-purple-950/50 text-transparent scale-95'
                    : 'bg-white text-purple-900 border-purple-300 shadow-lg hover:scale-105 active:translate-y-0.5 cursor-pointer'
                }`}
              >
                {letter}
              </button>
            );
          })}
        </div>

        {/* Answer Slots */}
        <div className="flex flex-col items-center gap-3">
          <div className={`flex flex-wrap justify-center gap-2.5 sm:gap-3 ${shake ? 'animate-wordy-shake' : ''}`}>
            {slots.map((poolIdx, slotIdx) => {
              const char = poolIdx !== null ? pool[poolIdx] : '';
              const isLocked = lockedIndices.includes(slotIdx);
              return (
                <button
                  key={slotIdx}
                  type="button"
                  onClick={() => handleTapSlot(slotIdx)}
                  className={`w-13 h-14 sm:w-15 sm:h-16 rounded-2xl font-display font-bold text-2xl sm:text-3xl flex items-center justify-center transition-transform ${
                    char
                      ? isLocked
                        ? 'bg-emerald-500 border-b-4 border-emerald-700 text-white shadow-md'
                        : 'bg-amber-300 border-b-4 border-amber-600 text-amber-950 cursor-pointer animate-wordy-pop shadow-md'
                      : 'bg-white/15 border-2 border-dashed border-white/40 text-white/30'
                  }`}
                >
                  {char}
                </button>
              );
            })}
          </div>
        </div>

        {/* Booster & Action Controls */}
        <div className="w-full flex flex-wrap items-center justify-center gap-2.5 pt-2">
          <button
            type="button"
            onClick={handleHint}
            className="px-4 py-3 rounded-2xl bg-amber-300 hover:bg-amber-200 text-amber-950 font-display font-bold text-sm border-b-4 border-amber-600 flex items-center gap-1.5 cursor-pointer shadow-md"
          >
            <Lightbulb className="w-4 h-4" />
            Maslahat ({profile.hints})
          </button>

          <button
            type="button"
            onClick={handleSkipPuzzle}
            className="px-4 py-3 rounded-2xl bg-sky-400 hover:bg-sky-300 text-sky-950 font-display font-bold text-sm border-b-4 border-sky-700 flex items-center gap-1.5 cursor-pointer shadow-md"
          >
            <SkipForward className="w-4 h-4" />
            Oʻtkazish ({profile.powerups.skipWord || 0})
          </button>

          <button
            type="button"
            onClick={handleShuffle}
            className="px-4 py-3 rounded-2xl bg-black/25 hover:bg-black/35 text-white font-display font-bold text-sm border-b-4 border-purple-950 flex items-center gap-1.5 cursor-pointer"
          >
            <Shuffle className="w-4 h-4" />
            Aralashtirish
          </button>
        </div>
      </main>

      <VictoryModal
        reward={victoryReward}
        onContinue={() => {
          setVictoryReward(null);
          onBack();
        }}
        onPlayAgain={() => loadPuzzle(puzzleIdx + 1)}
      />
    </div>
  );
};
