import React, { useState } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Smartphone,
  Moon,
  Sun,
  Palette,
  Flame,
  CloudUpload,
  LogOut,
  Check,
} from 'lucide-react';
import { PlayerProfile, PlayerSettings } from '../types/game';

interface SettingsModalProps {
  open: boolean;
  profile: PlayerProfile;
  isSignedIn: boolean;
  userEmail?: string | null;
  syncBusy: boolean;
  syncStatusMsg: string;
  onClose: () => void;
  onToggleSetting: (key: keyof PlayerSettings) => void;
  onUpdateName: (name: string) => void;
  onCloudSave: () => Promise<void>;
  onSignOut: () => Promise<void>;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  open,
  profile,
  isSignedIn,
  userEmail,
  syncBusy,
  syncStatusMsg,
  onClose,
  onToggleSetting,
  onUpdateName,
  onCloudSave,
  onSignOut,
}) => {
  const [nameInput, setNameInput] = useState(profile.displayName);
  const [nameSaved, setNameSaved] = useState(false);

  if (!open) return null;

  const s = profile.settings;

  const handleSaveName = () => {
    const clean = nameInput.trim().slice(0, 24);
    if (!clean) return;
    onUpdateName(clean);
    setNameSaved(true);
    setTimeout(() => setNameSaved(false), 1600);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-md max-h-[90vh] flex flex-col rounded-3xl bg-gradient-to-b from-blue-500 via-indigo-600 to-blue-800 dark:from-slate-800 dark:via-slate-900 dark:to-slate-950 text-white border-2 border-sky-300/50 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="shrink-0 px-5 py-4 flex items-center justify-between border-b border-white/15">
          <h2 className="font-display font-bold text-xl tracking-wide">SOZLAMALAR</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Yopish"
            className="w-9 h-9 rounded-xl bg-white/15 hover:bg-white/25 flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 min-h-0 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Player Name Input */}
          <div className="rounded-2xl bg-white/12 p-3.5 border border-white/20 space-y-2">
            <label className="block text-xs font-bold text-sky-100">
              Oʻyinchi ismi
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                maxLength={24}
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-950/35 border border-white/25 text-sm font-bold text-white placeholder:text-white/50"
              />
              <button
                type="button"
                onClick={handleSaveName}
                className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-display font-bold text-sm border-b-4 border-amber-600 cursor-pointer flex items-center justify-center gap-1.5 shrink-0"
              >
                {nameSaved ? <Check className="w-4 h-4" /> : null}
                {nameSaved ? 'Saqlandi' : 'Saqlash'}
              </button>
            </div>
          </div>

          {/* 5 Settings Cards Grid (3 top + 2 bottom, spacious & never cramped) */}
          <div className="grid grid-cols-6 gap-2.5">
            {/* 1. Sound */}
            <button
              type="button"
              onClick={() => onToggleSetting('sound')}
              className="col-span-2 rounded-2xl bg-white/95 dark:bg-slate-800 text-slate-900 dark:text-white p-3 flex flex-col items-center justify-center gap-1 shadow border-b-4 border-sky-200 dark:border-slate-950 cursor-pointer"
            >
              {s.sound ? (
                <Volume2 className="w-7 h-7 text-sky-600 dark:text-sky-400" />
              ) : (
                <VolumeX className="w-7 h-7 text-slate-400" />
              )}
              <span className="font-display text-xs font-bold">Ovoz</span>
              <span
                className={`text-[10px] font-extrabold ${
                  s.sound ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'
                }`}
              >
                {s.sound ? 'YOQILGAN' : 'OʻCHIQ'}
              </span>
            </button>

            {/* 2. Vibration */}
            <button
              type="button"
              onClick={() => onToggleSetting('vibration')}
              className="col-span-2 rounded-2xl bg-white/95 dark:bg-slate-800 text-slate-900 dark:text-white p-3 flex flex-col items-center justify-center gap-1 shadow border-b-4 border-sky-200 dark:border-slate-950 cursor-pointer"
            >
              <Smartphone
                className={`w-7 h-7 ${
                  s.vibration ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'
                }`}
              />
              <span className="font-display text-xs font-bold">Tebranish</span>
              <span
                className={`text-[10px] font-extrabold ${
                  s.vibration ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'
                }`}
              >
                {s.vibration ? 'YOQILGAN' : 'OʻCHIQ'}
              </span>
            </button>

            {/* 3. Dark Mode */}
            <button
              type="button"
              onClick={() => onToggleSetting('darkMode')}
              className="col-span-2 rounded-2xl bg-white/95 dark:bg-slate-800 text-slate-900 dark:text-white p-3 flex flex-col items-center justify-center gap-1 shadow border-b-4 border-sky-200 dark:border-slate-950 cursor-pointer"
            >
              {s.darkMode ? (
                <Moon className="w-7 h-7 text-indigo-400" />
              ) : (
                <Sun className="w-7 h-7 text-amber-500" />
              )}
              <span className="font-display text-xs font-bold">Tungi rejim</span>
              <span
                className={`text-[10px] font-extrabold ${
                  s.darkMode ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'
                }`}
              >
                {s.darkMode ? 'YOQILGAN' : 'OʻCHIQ'}
              </span>
            </button>

            {/* 4. Blue Theme */}
            <button
              type="button"
              onClick={() => onToggleSetting('blueTheme')}
              className="col-span-3 rounded-2xl bg-white/95 dark:bg-slate-800 text-slate-900 dark:text-white p-3 flex flex-col items-center justify-center gap-1 shadow border-b-4 border-sky-200 dark:border-slate-950 cursor-pointer"
            >
              <Palette
                className={`w-7 h-7 ${
                  s.blueTheme ? 'text-blue-600 dark:text-blue-400' : 'text-orange-500'
                }`}
              />
              <span className="font-display text-xs font-bold">Moviy mavzu</span>
              <span
                className={`text-[10px] font-extrabold ${
                  s.blueTheme ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'
                }`}
              >
                {s.blueTheme ? 'YOQILGAN' : 'OʻCHIQ'}
              </span>
            </button>

            {/* 5. Hard Mode */}
            <button
              type="button"
              onClick={() => onToggleSetting('hardMode')}
              className="col-span-3 rounded-2xl bg-white/95 dark:bg-slate-800 text-slate-900 dark:text-white p-3 flex flex-col items-center justify-center gap-1 shadow border-b-4 border-sky-200 dark:border-slate-950 cursor-pointer"
            >
              <Flame
                className={`w-7 h-7 ${
                  s.hardMode ? 'text-rose-600 dark:text-rose-400' : 'text-slate-400'
                }`}
              />
              <span className="font-display text-xs font-bold">Qiyin rejim</span>
              <span
                className={`text-[10px] font-extrabold ${
                  s.hardMode ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'
                }`}
              >
                {s.hardMode ? 'YOQILGAN' : 'OʻCHIQ'}
              </span>
            </button>
          </div>

          {/* Dedicated Spacious Cloud Save Button */}
          <button
            type="button"
            disabled={syncBusy}
            onClick={onCloudSave}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-b from-emerald-400 to-emerald-600 hover:from-emerald-300 hover:to-emerald-500 text-white font-display font-bold text-sm sm:text-base border-b-4 border-emerald-800 shadow-lg flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-60 active:translate-y-0.5 transition-transform"
          >
            <CloudUpload className="w-5 h-5 shrink-0" />
            <span>
              {syncBusy
                ? 'Bulutga saqlanmoqda...'
                : isSignedIn
                ? 'Taraqqiyotni bulutga saqlash'
                : 'Google orqali kirish va saqlash'}
            </span>
          </button>

          {/* Cloud Sync Status */}
          <div className="rounded-2xl bg-black/25 p-3 text-xs flex items-center justify-between gap-2">
            <div className="min-w-0">
              <div className="font-semibold truncate">
                {isSignedIn
                  ? `Ulangan: ${userEmail || 'Google hisob'}`
                  : 'Mahalliy saqlash faol (bulutga ulanmagan)'}
              </div>
              {syncStatusMsg && (
                <div className="text-amber-300 font-semibold mt-0.5">{syncStatusMsg}</div>
              )}
            </div>
            {isSignedIn && (
              <button
                type="button"
                onClick={onSignOut}
                className="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-xs font-bold flex items-center gap-1 cursor-pointer shrink-0"
              >
                <LogOut className="w-3.5 h-3.5" />
                Chiqish
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
