export type GameView =
  | 'HOME'
  | 'CLASSIC'
  | 'DAILY'
  | 'CIRCLE'
  | 'MIXED'
  | 'TOGETHER';

export type DuelVariant = 'classic_duel' | 'battle_duel' | 'team_duel';

export type DuelConnectionType = 'online' | 'bot' | 'offline_code';

export type ThemeId = 'sunset' | 'blue' | 'emerald';

export type AvatarId =
  | 'boy_blue'
  | 'girl_amber'
  | 'cool_shades'
  | 'crown_pro'
  | 'bot_cyber'
  | 'scholar_owl';

export interface PlayerSettings {
  sound: boolean;
  vibration: boolean;
  darkMode: boolean;
  blueTheme: boolean;
  hardMode: boolean;
}

export interface PowerupInventory {
  revealLetter: number;
  freezeTime: number;
  scrambleRival: number;
  skipWord?: number;
}

export interface DailyChallengeState {
  dateKey: string;
  weekKey?: string;
  solvedIndices: number[];
  claimedChest: boolean;
  activityDays?: string[];
}

export interface TaskProgress {
  progress: number;
  claimed: boolean;
}

export interface PlayerStats {
  classicPlayed: number;
  classicWon: number;
  classicStreak: number;
  dailyCompleted: number;
  circleWordsFound: number;
  circleLevel: number;
  mixedSolved: number;
  duelsPlayed: number;
  duelsWon: number;
  currentWinStreak: number;
  bestWinStreak: number;
  totalUzcEarned: number;
  totalUzcSpent: number;
}

export type BadgeIconKey =
  | 'first_win'
  | 'streak_5'
  | 'streak_10'
  | 'spender_1000'
  | 'treasury_2000'
  | 'circle_master'
  | 'duel_champ'
  | 'collector';

export interface AchievementBadgeDefinition {
  id: string;
  iconKey: BadgeIconKey;
  titleUz: string;
  descUz: string;
  target: number;
  rewardUzc: number;
  rewardXp: number;
  metric: (profile: PlayerProfile) => number;
}

export interface PlayerProfile {
  uid: string;
  displayName: string;
  avatarId: AvatarId;
  uzc: number;
  xp: number;
  level: number;
  hints: number;
  powerups: PowerupInventory;
  ownedThemes: ThemeId[];
  activeTheme: ThemeId;
  ownedAvatars: AvatarId[];
  dailyState: DailyChallengeState;
  lastFreeCoinDate: string;
  tasks: Record<string, TaskProgress>;
  stats: PlayerStats;
  settings: PlayerSettings;
}

export interface TaskDefinition {
  id: string;
  category: 'daily' | 'weekly' | 'achievement';
  titleUz: string;
  target: number;
  rewardUzc: number;
  rewardXp: number;
  statKey:
    | 'classicPlayed'
    | 'classicWon'
    | 'dailyCompleted'
    | 'circleWordsFound'
    | 'mixedSolved'
    | 'duelsPlayed'
    | 'duelsWon';
}

export type LetterState = 'empty' | 'tbd' | 'correct' | 'present' | 'absent';

export interface DuelPlayerState {
  uid: string;
  displayName: string;
  avatarId: AvatarId;
  team: 'blue' | 'red';
  score: number;
  roundIndex: number;
  solvedCount: number;
  finished: boolean;
  scrambleUntilMs?: number;
}

export interface DuelRoom {
  inviteCode: string;
  hostId: string;
  variant: DuelVariant;
  status: 'waiting' | 'active' | 'finished';
  maxPlayers: number;
  totalRounds: number;
  durationSeconds: number;
  words: string[];
  participantIds: string[];
  playerStates: Record<string, DuelPlayerState>;
  winnerTeam: string;
  startedAtMs: number;
}

export interface VictoryReward {
  titleUz: string;
  subtitleUz: string;
  uzc: number;
  xp: number;
  isWin: boolean;
}
