import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  BarChart3,
  CheckCircle2,
  Flame,
  Lightbulb,
  RotateCcw,
  SkipForward,
} from 'lucide-react';
import {
  evaluateWordleGuess,
  validateWordRealtime,
  WORDS_5_TARGETS,
  WORDS_5_VALID,
  WORDS_6_TARGETS,
  WORDS_6_VALID,
} from '../data/words';
import { LetterState, PlayerProfile, VictoryReward } from '../types/game';
import { soundFx, triggerHaptic } from '../utils/sound';
import { UzcCoinIcon } from './GameIcons';
import { VictoryModal } from './VictoryModal';
import { WordKeyboard } from './WordKeyboard';

interface ClassicModeProps {
  profile: PlayerProfile;
  onBack: () => void;
  onUseHint: () => boolean;
  onUseSkipWord: () => boolean;
  onCompleteGame: (won: boolean, attempts: number, rewardUzc: number, rewardXp: number) => void;
}

const MAX_ATTEMPTS = 6;

function pickWordForLength(len: 5 | 6): string {
  const pool = len === 5 ? WORDS_5_TARGETS : WORDS_6_TARGETS;
  return pool[Math.floor(Math.random() * pool.length)];
}

export const ClassicMode: React.FC<ClassicModeProps> = ({
  profile,
  onBack,
  onUseHint,
  onUseSkipWord,
  onCompleteGame,
}) => {
  const [wordLen, setWordLen] = useState<5 | 6 | null>(null);
  const [target, setTarget] = useState<string>('');
  const [guesses, setGuesses] = useState<string[]>([]);
  const [currentGuess, setCurrentGuess] = useState<string>('');
  const [statusMsg, setStatusMsg] = useState<string>('');
  const [shakeRow, setShakeRow] = useState<boolean>(false);
  const [showStats, setShowStats] = useState<boolean>(false);
  const [gameOver, setGameOver] = useState<'playing' | 'won' | 'lost'>('playing');
  const [victoryReward, setVictoryReward] = useState<VictoryReward | null>(null);
  const [revealedHintCols, setRevealedHintCols] = useState<Record<number, string>>({});

  const effectiveTheme = profile.settings.blueTheme ? 'blue' : profile.activeTheme;
  const arenaGradient =
    effectiveTheme === 'blue'
      ? 'from-sky-500 via-blue-600 to-indigo-700'
      : effectiveTheme === 'emerald'
      ? 'from-emerald-500 via-teal-600 to-green-800'
      : 'from-orange-500 via-amber-500 to-orange-600';

  const wordValidation = useMemo(() => {
    if (!wordLen || gameOver !== 'playing') return 'empty' as const;
    return validateWordRealtime(currentGuess, wordLen);
  }, [currentGuess, gameOver, wordLen]);

  const isInvalidRealtime =
    wordValidation === 'invalid_prefix' || wordValidation === 'invalid_word';
  const isValidFullWord = wordValidation === 'valid_word';

  const startRoundWithLength = useCallback(
    (len: 5 | 6) => {
      soundFx.key(profile.settings.sound);
      setWordLen(len);
      setTarget(pickWordForLength(len));
      setGuesses([]);
      setCurrentGuess('');
      setGameOver('playing');
      setVictoryReward(null);
      setRevealedHintCols({});
      setStatusMsg('');
    },
    [profile.settings.sound]
  );

  const keyStates = useMemo(() => {
    const map: Record<string, LetterState> = {};
    if (!target) return map;
    const rank: Record<LetterState, number> = {
      empty: 0,
      tbd: 1,
      absent: 2,
      present: 3,
      correct: 4,
    };
    guesses.forEach((guess) => {
      const evals = evaluateWordleGuess(guess, target);
      guess.split('').forEach((ch, idx) => {
        const next = evals[idx];
        if (!map[ch] || rank[next] > rank[map[ch]]) {
          map[ch] = next;
        }
      });
    });
    return map;
  }, [guesses, target]);

  const showToast = useCallback((msg: string) => {
    setStatusMsg(msg);
    setTimeout(() => {
      setStatusMsg((prev) => (prev === msg ? '' : prev));
    }, 2400);
  }, []);

  const triggerRowShake = useCallback(() => {
    setShakeRow(true);
    setTimeout(() => setShakeRow(false), 350);
  }, []);

  const startNewRound = useCallback(() => {
    if (!wordLen) return;
    setTarget(pickWordForLength(wordLen));
    setGuesses([]);
    setCurrentGuess('');
    setGameOver('playing');
    setVictoryReward(null);
    setRevealedHintCols({});
    setStatusMsg('');
  }, [wordLen]);

  const handleKey = useCallback(
    (letter: string) => {
      if (!wordLen || gameOver !== 'playing' || currentGuess.length >= wordLen) return;
      soundFx.key(profile.settings.sound);
      triggerHaptic(profile.settings.vibration, 10);
      setCurrentGuess((prev) => prev + letter);
    },
    [wordLen, gameOver, currentGuess.length, profile.settings.sound, profile.settings.vibration]
  );

  const handleBackspace = useCallback(() => {
    if (!wordLen || gameOver !== 'playing' || currentGuess.length === 0) return;
    soundFx.delete(profile.settings.sound);
    setCurrentGuess((prev) => prev.slice(0, -1));
  }, [wordLen, gameOver, currentGuess.length, profile.settings.sound]);

  const handleEnter = useCallback(() => {
    if (!wordLen || gameOver !== 'playing') return;
    if (currentGuess.length < wordLen) {
      soundFx.error(profile.settings.sound);
      triggerHaptic(profile.settings.vibration, [25, 30, 25]);
      triggerRowShake();
      showToast(`${wordLen} ta harf kiriting!`);
      return;
    }

    const validSet = wordLen === 5 ? WORDS_5_VALID : WORDS_6_VALID;
    if (!validSet.has(currentGuess)) {
      soundFx.error(profile.settings.sound);
      triggerHaptic(profile.settings.vibration, [25, 30, 25]);
      triggerRowShake();
      return;
    }

    // Hard Mode verification
    if (profile.settings.hardMode && guesses.length > 0) {
      const lastGuess = guesses[guesses.length - 1];
      const lastEval = evaluateWordleGuess(lastGuess, target);
      for (let i = 0; i < wordLen; i++) {
        if (lastEval[i] === 'correct' && currentGuess[i] !== lastGuess[i]) {
          soundFx.error(profile.settings.sound);
          triggerRowShake();
          showToast(`Qiyin rejim: ${i + 1}-oʻrinda ${lastGuess[i]} boʻlishi shart`);
          return;
        }
      }
      for (let i = 0; i < wordLen; i++) {
        if (lastEval[i] === 'present' && !currentGuess.includes(lastGuess[i])) {
          soundFx.error(profile.settings.sound);
          triggerRowShake();
          showToast(`Qiyin rejim: soʻzda ${lastGuess[i]} harfi boʻlishi shart`);
          return;
        }
      }
    }

    const nextGuesses = [...guesses, currentGuess];
    setGuesses(nextGuesses);
    setCurrentGuess('');

    for (let i = 0; i < wordLen; i++) {
      soundFx.flip(profile.settings.sound, i);
    }

    if (currentGuess === target) {
      setGameOver('won');
      const lenBonus = wordLen === 6 ? 15 : 0;
      const bonus = Math.max(10, (MAX_ATTEMPTS - nextGuesses.length + 1) * 12) + lenBonus;
      const rewardUzc = 45 + bonus;
      const rewardXp = 40 + bonus;
      setTimeout(() => {
        soundFx.victory(profile.settings.sound);
        triggerHaptic(profile.settings.vibration, [30, 40, 60]);
        onCompleteGame(true, nextGuesses.length, rewardUzc, rewardXp);
        setVictoryReward({
          titleUz: 'Ajoyib!',
          subtitleUz: `Siz "${target}" (${wordLen} harfli) soʻzini ${nextGuesses.length} urinishda topdingiz.`,
          uzc: rewardUzc,
          xp: rewardXp,
          isWin: true,
        });
      }, 450);
    } else if (nextGuesses.length >= MAX_ATTEMPTS) {
      setGameOver('lost');
      setTimeout(() => {
        soundFx.error(profile.settings.sound);
        onCompleteGame(false, MAX_ATTEMPTS, 15, 15);
        setVictoryReward({
          titleUz: 'Keyingi safar!',
          subtitleUz: `Toʻgʻri soʻz: "${target}". Harakat uchun mukofot:`,
          uzc: 15,
          xp: 15,
          isWin: false,
        });
      }, 450);
    }
  }, [
    wordLen,
    gameOver,
    currentGuess,
    profile.settings.sound,
    profile.settings.vibration,
    profile.settings.hardMode,
    guesses,
    target,
    triggerRowShake,
    showToast,
    onCompleteGame,
  ]);

  const handleHint = () => {
    if (!wordLen || gameOver !== 'playing') return;
    const knownGreen = new Set<number>(Object.keys(revealedHintCols).map(Number));
    guesses.forEach((g) => {
      evaluateWordleGuess(g, target).forEach((s, i) => {
        if (s === 'correct') knownGreen.add(i);
      });
    });

    const candidates: number[] = [];
    for (let i = 0; i < wordLen; i++) {
      if (!knownGreen.has(i)) candidates.push(i);
    }

    if (candidates.length === 0) {
      showToast('Barcha harflar allaqachon maʼlum!');
      return;
    }

    const ok = onUseHint();
    if (!ok) {
      showToast('Maslahat tugagan! Doʻkondan UZC ga oling');
      return;
    }

    const pick = candidates[Math.floor(Math.random() * candidates.length)];
    soundFx.coin(profile.settings.sound);
    setRevealedHintCols((prev) => ({ ...prev, [pick]: target[pick] }));
    showToast(`${pick + 1}-harf ochildi: ${target[pick]}`);
  };

  const handleSkipWord = () => {
    if (!wordLen || gameOver !== 'playing') return;
    const ok = onUseSkipWord();
    if (!ok) {
      soundFx.error(profile.settings.sound);
      showToast("Oʻtkazish boosteri yoʻq (yoki 40 UZC kerak)");
      return;
    }
    soundFx.powerup(profile.settings.sound);
    triggerHaptic(profile.settings.vibration, 20);
    startNewRound();
    showToast('Yangi soʻzga oʻtildi!');
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (!wordLen || showStats || victoryReward) return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key === 'Enter') {
        e.preventDefault();
        handleEnter();
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (/^[a-zA-Z]$/.test(e.key)) {
        e.preventDefault();
        handleKey(e.key.toUpperCase());
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [wordLen, handleEnter, handleBackspace, handleKey, showStats, victoryReward]);

  // Step 1: Minimalist 2-button Classic picker (5 harfli vs 6 harfli — zero clutter)
  if (!wordLen) {
    return (
      <div
        className={`min-h-[100dvh] w-full flex flex-col bg-gradient-to-b ${arenaGradient} dark:from-slate-900 dark:via-slate-950 dark:to-black text-white`}
      >
        <header className="w-full max-w-md mx-auto px-4 pt-4 pb-2 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={onBack}
            aria-label="Orqaga"
            className="w-10 h-10 rounded-xl bg-black/20 hover:bg-black/30 border border-white/20 flex items-center justify-center transition-colors cursor-pointer shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <h1 className="font-display font-bold text-2xl tracking-wider drop-shadow-sm">
            CLASSIC
          </h1>

          <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-black/25 border border-white/20 shrink-0">
            <UzcCoinIcon className="w-4 h-4" />
            <span className="font-mono-num text-xs sm:text-sm font-bold text-amber-200">
              {profile.uzc}
            </span>
          </div>
        </header>

        <main className="flex-1 w-full max-w-sm mx-auto px-5 py-8 flex flex-col justify-center gap-4">
          <button
            type="button"
            onClick={() => startRoundWithLength(5)}
            className="w-full py-6 px-6 rounded-3xl bg-gradient-to-b from-emerald-400 to-emerald-600 hover:from-emerald-300 hover:to-emerald-500 text-white border-b-[6px] border-emerald-800 shadow-xl flex items-center justify-center gap-3 active:translate-y-1 transition-transform cursor-pointer"
          >
            <span className="font-display font-bold text-2xl sm:text-3xl tracking-wide drop-shadow-sm">
              5 HARFLI
            </span>
          </button>

          <button
            type="button"
            onClick={() => startRoundWithLength(6)}
            className="w-full py-6 px-6 rounded-3xl bg-gradient-to-b from-amber-300 to-amber-500 hover:from-amber-200 hover:to-amber-400 text-amber-950 border-b-[6px] border-amber-700 shadow-xl flex items-center justify-center gap-3 active:translate-y-1 transition-transform cursor-pointer"
          >
            <span className="font-display font-bold text-2xl sm:text-3xl tracking-wide">
              6 HARFLI
            </span>
          </button>
        </main>
      </div>
    );
  }

  return (
    <div
      className={`min-h-[100dvh] w-full flex flex-col justify-between bg-gradient-to-b ${arenaGradient} dark:from-slate-900 dark:via-slate-950 dark:to-black text-white`}
    >
      {/* Top Arena Bar */}
      <header className="w-full max-w-lg mx-auto px-3 pt-3 pb-1 flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={onBack}
          aria-label="Orqaga"
          className="w-10 h-10 rounded-xl bg-black/20 hover:bg-black/30 border border-white/20 flex items-center justify-center transition-colors cursor-pointer shrink-0"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="text-center">
          <h1 className="font-display font-bold text-xl tracking-wide flex items-center justify-center gap-1.5 drop-shadow-sm">
            CLASSIC · {wordLen}
            {profile.settings.hardMode && (
              <Flame className="w-4 h-4 text-rose-300 fill-rose-400" />
            )}
          </h1>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-black/25 border border-white/20">
            <UzcCoinIcon className="w-4 h-4" />
            <span className="font-mono-num text-xs sm:text-sm font-bold text-amber-200">
              {profile.uzc}
            </span>
          </div>
          <button
            type="button"
            onClick={() => setShowStats(true)}
            aria-label="Statistika"
            className="w-10 h-10 rounded-xl bg-black/20 hover:bg-black/30 border border-white/20 flex items-center justify-center transition-colors cursor-pointer"
          >
            <BarChart3 className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Cheerful Wordle Booster & Quick Switch Strip */}
      <div className="w-full max-w-lg mx-auto px-3 flex items-center justify-center gap-1.5 flex-wrap">
        <button
          type="button"
          onClick={handleHint}
          disabled={gameOver !== 'playing'}
          className="px-3 py-1.5 rounded-xl bg-amber-300 hover:bg-amber-200 text-amber-950 font-display font-bold text-xs border-b-2 border-amber-600 flex items-center gap-1 cursor-pointer disabled:opacity-45 whitespace-nowrap shadow-sm"
        >
          <Lightbulb className="w-3.5 h-3.5" />
          Maslahat ({profile.hints})
        </button>

        <button
          type="button"
          onClick={handleSkipWord}
          disabled={gameOver !== 'playing'}
          className="px-3 py-1.5 rounded-xl bg-sky-400 hover:bg-sky-300 text-sky-950 font-display font-bold text-xs border-b-2 border-sky-700 flex items-center gap-1 cursor-pointer disabled:opacity-45 whitespace-nowrap shadow-sm"
        >
          <SkipForward className="w-3.5 h-3.5" />
          Oʻtkazish ({profile.powerups.skipWord || 0})
        </button>

        <button
          type="button"
          onClick={() => setWordLen(wordLen === 5 ? 6 : 5)}
          className="px-2.5 py-1.5 rounded-xl bg-black/25 hover:bg-black/35 border border-white/25 text-xs font-display font-bold text-white cursor-pointer whitespace-nowrap"
        >
          {wordLen === 5 ? '6 harfli' : '5 harfli'}
        </button>

        <button
          type="button"
          onClick={startNewRound}
          aria-label="Yangi soʻz"
          className="p-1.5 rounded-xl bg-black/25 hover:bg-black/35 border border-white/25 text-white cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Real-time Per-Letter Dictionary Validation Banner OR Toast */}
      <div className="h-7 flex items-center justify-center px-3 my-0.5">
        {wordValidation === 'invalid_word' ? (
          <div className="px-3.5 py-1 rounded-xl bg-rose-600 text-white border border-rose-300 text-xs font-bold shadow-lg flex items-center gap-1.5 animate-wordy-pop">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            Lugʻatda bunday soʻz mavjud emas
          </div>
        ) : wordValidation === 'invalid_prefix' ? (
          <div className="px-3.5 py-1 rounded-xl bg-rose-600 text-white border border-rose-300 text-xs font-bold shadow-lg flex items-center gap-1.5 animate-wordy-pop">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            «{currentGuess}» bilan boshlanuvchi soʻz lugʻatda yoʻq
          </div>
        ) : statusMsg ? (
          <div className="px-3.5 py-1 rounded-xl bg-slate-900/95 border border-amber-400/50 text-amber-200 text-xs font-bold shadow-lg">
            {statusMsg}
          </div>
        ) : isValidFullWord ? (
          <div className="px-3 py-0.5 rounded-xl bg-emerald-600/90 text-white border border-emerald-300/60 text-[11px] font-bold shadow flex items-center gap-1 animate-wordy-pop">
            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
            Soʻz lugʻatda mavjud
          </div>
        ) : null}
      </div>

      {/* Cheerful Wordle Board (5x6 or 6x6) */}
      <main className="flex-1 flex flex-col items-center justify-center px-3 py-1">
        <div
          className={`grid grid-rows-6 gap-1.5 sm:gap-2 w-full ${
            wordLen === 5 ? 'max-w-[280px] sm:max-w-[315px]' : 'max-w-[315px] sm:max-w-[355px]'
          }`}
        >
          {Array.from({ length: MAX_ATTEMPTS }).map((_, rowIdx) => {
            const isSubmitted = rowIdx < guesses.length;
            const isCurrent = rowIdx === guesses.length && gameOver === 'playing';
            const word = isSubmitted ? guesses[rowIdx] : isCurrent ? currentGuess : '';
            const evals = isSubmitted ? evaluateWordleGuess(word, target) : [];

            return (
              <div
                key={rowIdx}
                className={`grid ${wordLen === 5 ? 'grid-cols-5' : 'grid-cols-6'} gap-1.5 sm:gap-2 ${
                  isCurrent && shakeRow ? 'animate-wordy-shake' : ''
                }`}
              >
                {Array.from({ length: wordLen }).map((__, colIdx) => {
                  const char = word[colIdx] || '';
                  const hintChar = isCurrent && !char ? revealedHintCols[colIdx] : '';
                  const state = isSubmitted ? evals[colIdx] : char ? 'tbd' : 'empty';

                  let tileClasses =
                    isCurrent && isInvalidRealtime
                      ? 'bg-rose-500/20 dark:bg-rose-950/50 border-2 border-rose-400 text-white'
                      : 'bg-white/20 dark:bg-slate-800/75 border-2 border-white/40 dark:border-slate-600 text-white';
                  if (state === 'tbd') {
                    tileClasses = isInvalidRealtime
                      ? 'bg-rose-100 text-rose-700 border-2 border-rose-500 border-b-4 border-b-rose-600 ring-2 ring-rose-400/60 animate-wordy-pop shadow-md'
                      : isValidFullWord
                      ? 'bg-emerald-50 dark:bg-slate-700 text-emerald-950 dark:text-white border-2 border-emerald-400 border-b-4 border-b-emerald-600 animate-wordy-pop shadow-md'
                      : 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white border-2 border-white dark:border-sky-400 border-b-4 border-b-slate-300 dark:border-b-slate-900 animate-wordy-pop shadow-md';
                  } else if (state === 'correct') {
                    tileClasses =
                      'bg-emerald-500 border-2 border-emerald-400 border-b-4 border-b-emerald-700 text-white animate-wordy-flip shadow-md';
                  } else if (state === 'present') {
                    tileClasses =
                      'bg-amber-400 border-2 border-amber-300 border-b-4 border-b-amber-600 text-amber-950 animate-wordy-flip shadow-md';
                  } else if (state === 'absent') {
                    tileClasses =
                      'bg-slate-700/90 border-2 border-slate-600 border-b-4 border-b-slate-900 text-white/85 animate-wordy-flip';
                  }

                  return (
                    <div
                      key={colIdx}
                      style={isSubmitted ? { animationDelay: `${colIdx * 60}ms` } : undefined}
                      className={`aspect-square rounded-2xl flex items-center justify-center font-display font-bold text-2xl sm:text-3xl select-none transition-colors ${tileClasses}`}
                    >
                      {char ||
                        (hintChar ? (
                          <span className="text-amber-200/80 text-xl">{hintChar}</span>
                        ) : null)}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </main>

      {/* Keyboard */}
      <footer className="w-full px-2 sm:px-4 pb-5 pt-2">
        <WordKeyboard
          keyStates={keyStates}
          onKey={handleKey}
          onEnter={handleEnter}
          onBackspace={handleBackspace}
          disabled={gameOver !== 'playing'}
          invalidWord={isInvalidRealtime}
        />
      </footer>

      {/* Quick Stats Modal */}
      {showStats && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-slate-900 border-2 border-amber-300 dark:border-slate-700 p-6 text-slate-900 dark:text-white shadow-2xl">
            <h2 className="font-display font-bold text-xl text-center mb-4">
              Classic Statistika
            </h2>
            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="rounded-2xl bg-sky-50 dark:bg-white/5 p-3 text-center border border-sky-200 dark:border-white/10">
                <div className="font-mono-num text-2xl font-bold text-sky-600 dark:text-sky-300">
                  {profile.stats.classicPlayed}
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-300 mt-1">Oʻyinlar</div>
              </div>
              <div className="rounded-2xl bg-emerald-50 dark:bg-white/5 p-3 text-center border border-emerald-200 dark:border-white/10">
                <div className="font-mono-num text-2xl font-bold text-emerald-600 dark:text-emerald-400">
                  {profile.stats.classicPlayed > 0
                    ? Math.round((profile.stats.classicWon / profile.stats.classicPlayed) * 100)
                    : 0}
                  %
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-300 mt-1">Gʻalaba</div>
              </div>
              <div className="rounded-2xl bg-amber-50 dark:bg-white/5 p-3 text-center border border-amber-200 dark:border-white/10">
                <div className="font-mono-num text-2xl font-bold text-amber-600 dark:text-amber-400">
                  {profile.stats.classicStreak}
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-300 mt-1">Seriya</div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowStats(false)}
              className="w-full py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-amber-950 border-b-4 border-amber-600 font-display font-bold text-sm cursor-pointer"
            >
              Yopish
            </button>
          </div>
        </div>
      )}

      <VictoryModal
        reward={victoryReward}
        onContinue={() => {
          setVictoryReward(null);
          onBack();
        }}
        onPlayAgain={startNewRound}
      />
    </div>
  );
};
