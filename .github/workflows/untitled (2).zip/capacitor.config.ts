import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.wordy.uzgame',
  appName: 'WORDY',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
    backgroundColor: '#0F172A',
  },
  server: {
    androidScheme: 'https',
  },
};

export default config;
