import React, { useState } from 'react';
import { AvatarId, BadgeIconKey } from '../types/game';
import avatarBoyBlueImg from '../assets/images/avatar_boy_blue_1794729740969.jpg';
import avatarGirlRedImg from '../assets/images/avatar_girl_red_1794729742493.jpg';
import avatarCoolCrownImg from '../assets/images/avatar_cool_crown_1794729743051.jpg';

const AVATAR_IMAGE_PATHS: Partial<Record<AvatarId, string>> = {
  boy_blue: avatarBoyBlueImg,
  girl_amber: avatarGirlRedImg,
  crown_pro: avatarCoolCrownImg,
};

export const WordyCrownLogo: React.FC<{ size?: 'sm' | 'md' | 'lg' }> = ({ size = 'md' }) => {
  const widthCls = size === 'sm' ? 'w-36' : size === 'md' ? 'w-48 sm:w-56' : 'w-60 sm:w-68';
  return (
    <div className="flex flex-col items-center select-none">
      <svg
        viewBox="0 0 300 120"
        className={`${widthCls} h-auto drop-shadow-[0_8px_18px_rgba(59,7,100,0.45)]`}
        aria-label="WORDY"
        role="img"
      >
        <defs>
          <linearGradient id="logoCrownGold" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FEF9C3" />
            <stop offset="40%" stopColor="#FACC15" />
            <stop offset="100%" stopColor="#D97706" />
          </linearGradient>
          <linearGradient id="logoWordyStroke" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#7C3AED" />
            <stop offset="55%" stopColor="#5B21B6" />
            <stop offset="100%" stopColor="#2E1065" />
          </linearGradient>
          <linearGradient id="logoWordyFill" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="60%" stopColor="#F5F3FF" />
            <stop offset="100%" stopColor="#C4B5FD" />
          </linearGradient>
        </defs>

        {/* Radiant Star Accents */}
        <path
          d="M32 52 L36 60 L45 61 L38 67 L40 76 L32 71 L24 76 L26 67 L19 61 L28 60 Z"
          fill="#FDE047"
          stroke="#92400E"
          strokeWidth="2"
          strokeLinejoin="round"
        />
        <path
          d="M268 48 L271 55 L279 56 L273 61 L275 69 L268 65 L261 69 L263 61 L257 56 L265 55 Z"
          fill="#FDE047"
          stroke="#92400E"
          strokeWidth="2"
          strokeLinejoin="round"
        />
        <circle cx="60" cy="30" r="4" fill="#FEF08A" />
        <circle cx="240" cy="26" r="3.5" fill="#FEF08A" />

        {/* 3D Royal Crown */}
        <g transform="translate(113, 4)">
          <path
            d="M8 36 L3 12 L23 23 L37 3 L51 23 L71 12 L66 36 Z"
            fill="url(#logoCrownGold)"
            stroke="#78350F"
            strokeWidth="3"
            strokeLinejoin="round"
          />
          <path d="M10 34 L7 18 L24 26 L37 8" fill="none" stroke="#FEF9C3" strokeWidth="2" strokeLinecap="round" opacity="0.7" />
          <rect x="8" y="34" width="58" height="9" rx="3.5" fill="#F59E0B" stroke="#78350F" strokeWidth="2.5" />
          <circle cx="37" cy="22" r="4.5" fill="#EF4444" stroke="#78350F" strokeWidth="1.4" />
          <circle cx="21" cy="27" r="3" fill="#38BDF8" stroke="#78350F" strokeWidth="1.2" />
          <circle cx="53" cy="27" r="3" fill="#10B981" stroke="#78350F" strokeWidth="1.2" />
        </g>

        {/* Deep 3D Extruded Wordmark */}
        <text
          x="150"
          y="102"
          textAnchor="middle"
          fontFamily="Fredoka, Plus Jakarta Sans, sans-serif"
          fontWeight="700"
          fontSize="60"
          letterSpacing="2"
          stroke="#1E1B4B"
          strokeWidth="17"
          strokeLinejoin="round"
          fill="#1E1B4B"
        >
          WORDY
        </text>
        <text
          x="150"
          y="98"
          textAnchor="middle"
          fontFamily="Fredoka, Plus Jakarta Sans, sans-serif"
          fontWeight="700"
          fontSize="60"
          letterSpacing="2"
          stroke="url(#logoWordyStroke)"
          strokeWidth="12"
          strokeLinejoin="round"
          fill="url(#logoWordyStroke)"
        >
          WORDY
        </text>
        <text
          x="150"
          y="96"
          textAnchor="middle"
          fontFamily="Fredoka, Plus Jakarta Sans, sans-serif"
          fontWeight="700"
          fontSize="60"
          letterSpacing="2"
          fill="url(#logoWordyFill)"
        >
          WORDY
        </text>
      </svg>
    </div>
  );
};

export const UzcCoinIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg viewBox="0 0 44 44" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="uzcCoinRim" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FEF08A" />
        <stop offset="45%" stopColor="#FACC15" />
        <stop offset="100%" stopColor="#B45309" />
      </linearGradient>
      <radialGradient id="uzcCoinFace" cx="35%" cy="30%" r="70%">
        <stop offset="0%" stopColor="#FEF9C3" />
        <stop offset="55%" stopColor="#FBBF24" />
        <stop offset="100%" stopColor="#D97706" />
      </radialGradient>
    </defs>
    <circle cx="22" cy="24" r="18" fill="#78350F" />
    <circle cx="22" cy="21" r="18" fill="url(#uzcCoinRim)" stroke="#78350F" strokeWidth="2" />
    <circle cx="22" cy="21" r="13.5" fill="url(#uzcCoinFace)" stroke="#FEF3C7" strokeWidth="1.5" />
    <path d="M12 12 Q22 6.5 32 12" fill="none" stroke="#FFFFFF" strokeWidth="2.2" strokeLinecap="round" opacity="0.75" />
    <text
      x="22"
      y="25.5"
      textAnchor="middle"
      fontFamily="Fredoka, sans-serif"
      fontWeight="700"
      fontSize="13"
      fill="#78350F"
    >
      UZ
    </text>
  </svg>
);

/* High-craft 3D Game Mode Icons */

export const ClassicModeIcon: React.FC<{ className?: string }> = ({ className = 'w-11 h-11' }) => (
  <svg viewBox="0 0 56 56" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="clsBoard" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#FFFFFF" />
        <stop offset="100%" stopColor="#EDE9FE" />
      </linearGradient>
      <linearGradient id="clsGreen" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#34D399" />
        <stop offset="100%" stopColor="#059669" />
      </linearGradient>
      <linearGradient id="clsAmber" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#FDE047" />
        <stop offset="100%" stopColor="#D97706" />
      </linearGradient>
      <linearGradient id="clsViolet" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#A78BFA" />
        <stop offset="100%" stopColor="#6D28D9" />
      </linearGradient>
    </defs>
    {/* Extruded 3D shadow base */}
    <rect x="5" y="8" width="46" height="44" rx="12" fill="#4C1D95" />
    <rect x="5" y="4" width="46" height="44" rx="12" fill="url(#clsBoard)" stroke="#5B21B6" strokeWidth="2.4" />
    {/* Glossy top highlight */}
    <path d="M14 7.5 H42" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" opacity="0.9" />
    {/* 3x3 Wordle Tile Grid */}
    {[0, 1, 2].map((r) =>
      [0, 1, 2].map((c) => {
        const isGreen = (r === 0 && c === 0) || (r === 1 && c === 1) || (r === 2 && c === 2);
        const isAmber = (r === 0 && c === 2) || (r === 2 && c === 0);
        const fill = isGreen ? 'url(#clsGreen)' : isAmber ? 'url(#clsAmber)' : 'url(#clsViolet)';
        const letter = r === 0 && c === 0 ? 'W' : r === 1 && c === 1 ? 'O' : r === 2 && c === 2 ? 'R' : '';
        const x = 10.5 + c * 12;
        const y = 9.5 + r * 11.5;
        return (
          <g key={`${r}-${c}`}>
            <rect x={x} y={y + 1.5} width="10.5" height="10" rx="2.5" fill="#1E1B4B" opacity="0.28" />
            <rect x={x} y={y} width="10.5" height="10" rx="2.5" fill={fill} />
            {letter && (
              <text
                x={x + 5.25}
                y={y + 7.5}
                textAnchor="middle"
                fontFamily="Fredoka, sans-serif"
                fontWeight="700"
                fontSize="7"
                fill="#FFFFFF"
              >
                {letter}
              </text>
            )}
          </g>
        );
      })
    )}
  </svg>
);

export const DailyModeIcon: React.FC<{ className?: string }> = ({ className = 'w-11 h-11' }) => (
  <svg viewBox="0 0 56 56" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="dayHeader" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#FB7185" />
        <stop offset="100%" stopColor="#DC2626" />
      </linearGradient>
      <linearGradient id="dayBody" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#FFFFFF" />
        <stop offset="100%" stopColor="#E0F2FE" />
      </linearGradient>
    </defs>
    <rect x="6" y="11" width="44" height="41" rx="11" fill="#1E3A8A" />
    <rect x="6" y="7" width="44" height="41" rx="11" fill="url(#dayBody)" stroke="#1D4ED8" strokeWidth="2.4" />
    <path d="M6 17 C6 11.5 10.5 7 16 7 H40 C45.5 7 50 11.5 50 17 V21 H6 Z" fill="url(#dayHeader)" stroke="#991B1B" strokeWidth="1.5" />
    {/* Metallic Rings */}
    <rect x="15" y="3" width="6" height="10" rx="3" fill="#FACC15" stroke="#78350F" strokeWidth="1.6" />
    <rect x="35" y="3" width="6" height="10" rx="3" fill="#FACC15" stroke="#78350F" strokeWidth="1.6" />
    {/* Calendar Tiles */}
    <rect x="12" y="25" width="8.5" height="7" rx="2" fill="#3B82F6" />
    <rect x="23.5" y="25" width="8.5" height="7" rx="2" fill="#10B981" />
    <rect x="35" y="25" width="8.5" height="7" rx="2" fill="#F59E0B" />
    <rect x="12" y="35" width="8.5" height="7" rx="2" fill="#94A3B8" opacity="0.55" />
    <rect x="23.5" y="35" width="8.5" height="7" rx="2" fill="#94A3B8" opacity="0.55" />
    {/* Gleaming Check Badge */}
    <circle cx="39.5" cy="39" r="7" fill="#10B981" stroke="#FFFFFF" strokeWidth="2" />
    <path d="M36 39 L38.5 41.5 L43 36.5" fill="none" stroke="#FFFFFF" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const MixedModeIcon: React.FC<{ className?: string }> = ({ className = 'w-11 h-11' }) => (
  <svg viewBox="0 0 56 56" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="mixLeft" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#818CF8" />
        <stop offset="100%" stopColor="#4338CA" />
      </linearGradient>
      <linearGradient id="mixRight" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#38BDF8" />
        <stop offset="100%" stopColor="#0284C7" />
      </linearGradient>
      <linearGradient id="mixTop" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#F472B6" />
        <stop offset="100%" stopColor="#DB2777" />
      </linearGradient>
    </defs>
    {/* Left tilted tile A */}
    <g transform="rotate(-14 16 32)">
      <rect x="5" y="21" width="22" height="22" rx="6" fill="#312E81" />
      <rect x="5" y="18" width="22" height="22" rx="6" fill="url(#mixLeft)" stroke="#1E1B4B" strokeWidth="2" />
      <path d="M9 21 H22" stroke="#FFFFFF" strokeWidth="1.8" strokeLinecap="round" opacity="0.6" />
      <text x="16" y="34" textAnchor="middle" fontFamily="Fredoka, sans-serif" fontWeight="700" fontSize="14" fill="#FFFFFF">A</text>
    </g>
    {/* Right tilted tile C */}
    <g transform="rotate(13 40 32)">
      <rect x="29" y="22" width="22" height="22" rx="6" fill="#0C4A6E" />
      <rect x="29" y="19" width="22" height="22" rx="6" fill="url(#mixRight)" stroke="#082F49" strokeWidth="2" />
      <path d="M33 22 H46" stroke="#FFFFFF" strokeWidth="1.8" strokeLinecap="round" opacity="0.6" />
      <text x="40" y="35" textAnchor="middle" fontFamily="Fredoka, sans-serif" fontWeight="700" fontSize="14" fill="#FFFFFF">C</text>
    </g>
    {/* Center elevated tile B */}
    <g transform="rotate(-3 28 19)">
      <rect x="17" y="9" width="22" height="22" rx="6" fill="#831843" />
      <rect x="17" y="6" width="22" height="22" rx="6" fill="url(#mixTop)" stroke="#500724" strokeWidth="2" />
      <path d="M21 9 H34" stroke="#FFFFFF" strokeWidth="1.8" strokeLinecap="round" opacity="0.7" />
      <text x="28" y="22" textAnchor="middle" fontFamily="Fredoka, sans-serif" fontWeight="700" fontSize="14" fill="#FFFFFF">B</text>
    </g>
  </svg>
);

export const CircleModeIcon: React.FC<{ className?: string }> = ({ className = 'w-11 h-11' }) => (
  <svg viewBox="0 0 56 56" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="cirRing" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#38BDF8" />
        <stop offset="100%" stopColor="#0369A1" />
      </linearGradient>
    </defs>
    {/* Glowing Wheel Ring */}
    <circle cx="28" cy="28" r="19" fill="#0C4A6E" opacity="0.18" />
    <circle cx="28" cy="28" r="18" fill="none" stroke="url(#cirRing)" strokeWidth="5.5" />
    <circle cx="28" cy="28" r="18" fill="none" stroke="#BAE6FD" strokeWidth="1.8" />
    {/* Word Connection Triangle */}
    <polygon
      points="28,11 13,38 43,38"
      fill="none"
      stroke="#FDE047"
      strokeWidth="3"
      strokeLinejoin="round"
    />
    {/* 3D Letter Orbs */}
    <g>
      <circle cx="28" cy="11" r="8" fill="#0284C7" stroke="#082F49" strokeWidth="2" />
      <circle cx="25.5" cy="8.5" r="2.2" fill="#FFFFFF" opacity="0.65" />
      <text x="28" y="14.5" textAnchor="middle" fontFamily="Fredoka, sans-serif" fontWeight="700" fontSize="9.5" fill="#FFFFFF">W</text>
    </g>
    <g>
      <circle cx="13" cy="38" r="8" fill="#F59E0B" stroke="#78350F" strokeWidth="2" />
      <circle cx="10.5" cy="35.5" r="2.2" fill="#FFFFFF" opacity="0.65" />
      <text x="13" y="41.5" textAnchor="middle" fontFamily="Fredoka, sans-serif" fontWeight="700" fontSize="9.5" fill="#FFFFFF">O</text>
    </g>
    <g>
      <circle cx="43" cy="38" r="8" fill="#10B981" stroke="#064E3B" strokeWidth="2" />
      <circle cx="40.5" cy="35.5" r="2.2" fill="#FFFFFF" opacity="0.65" />
      <text x="43" y="41.5" textAnchor="middle" fontFamily="Fredoka, sans-serif" fontWeight="700" fontSize="9.5" fill="#FFFFFF">R</text>
    </g>
  </svg>
);

export const TogetherModeIcon: React.FC<{ className?: string }> = ({ className = 'w-11 h-11' }) => (
  <svg viewBox="0 0 56 56" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="togLeft" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#FB923C" />
        <stop offset="100%" stopColor="#C2410C" />
      </linearGradient>
      <linearGradient id="togRight" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#FDE047" />
        <stop offset="100%" stopColor="#EA580C" />
      </linearGradient>
    </defs>
    {/* Right Player */}
    <circle cx="37" cy="20" r="8.5" fill="url(#togRight)" stroke="#7C2D12" strokeWidth="2.2" />
    <path d="M25 46 C25 33 49 33 49 46 Z" fill="url(#togRight)" stroke="#7C2D12" strokeWidth="2.2" strokeLinejoin="round" />
    {/* Left Player */}
    <circle cx="20" cy="21" r="9.5" fill="url(#togLeft)" stroke="#7C2D12" strokeWidth="2.2" />
    <path d="M6 48 C6 34 34 34 34 48 Z" fill="url(#togLeft)" stroke="#7C2D12" strokeWidth="2.2" strokeLinejoin="round" />
    {/* Specular Highlights */}
    <circle cx="16.5" cy="17.5" r="2.5" fill="#FFFFFF" opacity="0.6" />
    <circle cx="34.5" cy="17" r="2" fill="#FFFFFF" opacity="0.6" />
    {/* Lightning Duel Spark */}
    <path d="M29 8 L25 16 H30 L27 24 L34 14 H29 Z" fill="#FEF08A" stroke="#78350F" strokeWidth="1.4" strokeLinejoin="round" />
  </svg>
);

export const ShopNavIcon: React.FC<{ className?: string }> = ({ className = 'w-7 h-7' }) => (
  <svg viewBox="0 0 44 44" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="shopBasket" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#FEF08A" />
        <stop offset="100%" stopColor="#F59E0B" />
      </linearGradient>
    </defs>
    {/* Coins inside cart */}
    <circle cx="21" cy="13" r="4.5" fill="#FACC15" stroke="#78350F" strokeWidth="1.5" />
    <circle cx="28" cy="14" r="4.5" fill="#FDE047" stroke="#78350F" strokeWidth="1.5" />
    {/* Cart Frame */}
    <path d="M5 9 H11.5 L16 28 H34.5 L38 15 H14" fill="none" stroke="#FFFFFF" strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round" />
    <polygon points="14,15 37,15 34,26 16.5,26" fill="url(#shopBasket)" stroke="#78350F" strokeWidth="1.6" />
    <line x1="21" y1="15" x2="22" y2="26" stroke="#92400E" strokeWidth="1.4" opacity="0.5" />
    <line x1="29" y1="15" x2="28" y2="26" stroke="#92400E" strokeWidth="1.4" opacity="0.5" />
    {/* Wheels */}
    <circle cx="18" cy="34" r="3.6" fill="#FFFFFF" stroke="#78350F" strokeWidth="1.8" />
    <circle cx="32" cy="34" r="3.6" fill="#FFFFFF" stroke="#78350F" strokeWidth="1.8" />
  </svg>
);

export const SettingsNavIcon: React.FC<{ className?: string }> = ({ className = 'w-7 h-7' }) => (
  <svg viewBox="0 0 44 44" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="gearMetal" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FFFFFF" />
        <stop offset="50%" stopColor="#E2E8F0" />
        <stop offset="100%" stopColor="#94A3B8" />
      </linearGradient>
    </defs>
    <path
      d="M19 4 H25 L26.2 9.2 A12 12 0 0 1 30.8 11.1 L35.2 8.2 L39.5 12.5 L36.6 16.9 A12 12 0 0 1 38.5 21.5 L43.7 22.7 V28.7 L38.5 29.9 A12 12 0 0 1 36.6 34.5 L39.5 38.9 L35.2 43.2 L30.8 40.3 A12 12 0 0 1 26.2 42.2 L25 47.4 H19 L17.8 42.2 A12 12 0 0 1 13.2 40.3 L8.8 43.2 L4.5 38.9 L7.4 34.5 A12 12 0 0 1 5.5 29.9 L0.3 28.7 V22.7 L5.5 21.5 A12 12 0 0 1 7.4 16.9 L4.5 12.5 L8.8 8.2 L13.2 11.1 A12 12 0 0 1 17.8 9.2 Z"
      transform="translate(2.2, -1.5) scale(0.9)"
      fill="url(#gearMetal)"
      stroke="#1E293B"
      strokeWidth="2.2"
      strokeLinejoin="round"
    />
    <circle cx="22" cy="21.5" r="7.5" fill="#F59E0B" stroke="#78350F" strokeWidth="2" />
    <circle cx="22" cy="21.5" r="3.4" fill="#FFFFFF" />
  </svg>
);

export const TasksNavIcon: React.FC<{ className?: string }> = ({ className = 'w-7 h-7' }) => (
  <svg viewBox="0 0 44 44" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="tskBoard" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#F59E0B" />
        <stop offset="100%" stopColor="#B45309" />
      </linearGradient>
    </defs>
    <rect x="8" y="8" width="28" height="33" rx="6" fill="url(#tskBoard)" stroke="#78350F" strokeWidth="2" />
    <rect x="11.5" y="11.5" width="21" height="26" rx="3.5" fill="#FFFBEB" />
    <rect x="15" y="4" width="14" height="7" rx="3" fill="#EF4444" stroke="#7F1D1D" strokeWidth="1.8" />
    <circle cx="22" cy="7.5" r="1.5" fill="#FEF08A" />
    {/* Checklist rows */}
    <path d="M14.5 19 L17 21.5 L21.5 16.5" fill="none" stroke="#10B981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    <line x1="24" y1="19.5" x2="29.5" y2="19.5" stroke="#64748B" strokeWidth="2.5" strokeLinecap="round" />
    <path d="M14.5 26.5 L17 29 L21.5 24" fill="none" stroke="#10B981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    <line x1="24" y1="27" x2="29.5" y2="27" stroke="#64748B" strokeWidth="2.5" strokeLinecap="round" />
    <circle cx="17.5" cy="33.5" r="2" fill="#F59E0B" />
    <line x1="24" y1="33.5" x2="29.5" y2="33.5" stroke="#94A3B8" strokeWidth="2.5" strokeLinecap="round" />
  </svg>
);

export const PlayerAvatarSvg: React.FC<{
  avatarId: AvatarId;
  className?: string;
}> = ({ avatarId, className = 'w-11 h-11' }) => {
  const [imgFailed, setImgFailed] = useState(false);
  const photoPath = AVATAR_IMAGE_PATHS[avatarId];

  if (photoPath && !imgFailed) {
    return (
      <div
        className={`${className} rounded-full overflow-hidden border-2 border-white shadow-md bg-sky-500 shrink-0`}
      >
        <img
          src={photoPath}
          alt={avatarId}
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className="w-full h-full object-cover"
        />
      </div>
    );
  }

  const isBot = avatarId === 'bot_cyber';
  const isOwl = avatarId === 'scholar_owl';
  const isShades = avatarId === 'cool_shades';

  return (
    <svg viewBox="0 0 64 64" className={`${className} shrink-0`} aria-hidden="true">
      <circle
        cx="32"
        cy="32"
        r="30"
        fill={isBot ? '#0EA5E9' : isOwl ? '#10B981' : isShades ? '#7C3AED' : '#38BDF8'}
        stroke="#FFFFFF"
        strokeWidth="3"
      />
      {isOwl ? (
        <g>
          <ellipse cx="32" cy="38" rx="17" ry="18" fill="#065F46" />
          <circle cx="24" cy="31" r="7" fill="#FEF3C7" />
          <circle cx="40" cy="31" r="7" fill="#FEF3C7" />
          <circle cx="24" cy="31" r="3.2" fill="#0F172A" />
          <circle cx="40" cy="31" r="3.2" fill="#0F172A" />
          <polygon points="32,35 28,41 36,41" fill="#F59E0B" />
          <path d="M16 20 L24 24 L40 24 L48 20 L42 15 L22 15 Z" fill="#1E293B" />
        </g>
      ) : isBot ? (
        <g>
          <path d="M14 58 C14 44 50 44 50 58" fill="#1E293B" />
          <rect x="17" y="18" width="30" height="24" rx="7" fill="#E2E8F0" stroke="#334155" strokeWidth="2.5" />
          <rect x="21" y="25" width="22" height="9" rx="4" fill="#0F172A" />
          <circle cx="27" cy="29.5" r="2.5" fill="#38BDF8" />
          <circle cx="37" cy="29.5" r="2.5" fill="#38BDF8" />
          <line x1="32" y1="18" x2="32" y2="11" stroke="#334155" strokeWidth="2.5" />
          <circle cx="32" cy="10" r="3" fill="#FACC15" />
        </g>
      ) : isShades ? (
        <g>
          <path d="M12 60 C12 43 52 43 52 60 Z" fill="#4C1D95" />
          <circle cx="32" cy="32" r="14" fill="#FDBA74" />
          <path
            d="M17 28 C17 16 26 12 34 13 C43 13 47 20 47 28 C43 22 36 21 30 22 C24 23 20 25 17 28 Z"
            fill="#1E1B4B"
          />
          {/* Cool Sunglasses */}
          <rect x="19" y="26" width="11" height="7.5" rx="2.5" fill="#0F172A" stroke="#FACC15" strokeWidth="1.5" />
          <rect x="34" y="26" width="11" height="7.5" rx="2.5" fill="#0F172A" stroke="#FACC15" strokeWidth="1.5" />
          <line x1="30" y1="29" x2="34" y2="29" stroke="#FACC15" strokeWidth="2" />
          <line x1="21" y1="28" x2="25" y2="32" stroke="#38BDF8" strokeWidth="1.5" opacity="0.7" />
          <line x1="36" y1="28" x2="40" y2="32" stroke="#38BDF8" strokeWidth="1.5" opacity="0.7" />
          <path d="M26 39 Q32 43 38 38" fill="none" stroke="#7C2D12" strokeWidth="2.2" strokeLinecap="round" />
        </g>
      ) : (
        <g>
          <path d="M12 60 C12 43 52 43 52 60 Z" fill="#2563EB" />
          <circle cx="32" cy="31" r="14" fill="#FDBA74" />
          <path
            d="M17 29 C17 17 26 13 33 14 C42 14 47 20 47 29 C43 22 36 21 30 22 C24 23 20 25 17 29 Z"
            fill="#451A03"
          />
          <circle cx="26" cy="31" r="2.3" fill="#0F172A" />
          <circle cx="38" cy="31" r="2.3" fill="#0F172A" />
          <path d="M27 38 Q32 42 37 38" fill="none" stroke="#7C2D12" strokeWidth="2" strokeLinecap="round" />
        </g>
      )}
    </svg>
  );
};

export const AchievementBadgeIcon: React.FC<{
  iconKey: BadgeIconKey;
  unlocked?: boolean;
  className?: string;
}> = ({ iconKey, unlocked = true, className = 'w-12 h-12' }) => {
  const palette: Record<BadgeIconKey, { outer: string; inner: string; rim: string }> = {
    first_win: { outer: '#F59E0B', inner: '#FEF08A', rim: '#92400E' },
    streak_5: { outer: '#EA580C', inner: '#FDBA74', rim: '#7C2D12' },
    streak_10: { outer: '#8B5CF6', inner: '#DDD6FE', rim: '#4C1D95' },
    spender_1000: { outer: '#10B981', inner: '#A7F3D0', rim: '#064E3B' },
    treasury_2000: { outer: '#EAB308', inner: '#FEF9C3', rim: '#854D0E' },
    circle_master: { outer: '#0284C7', inner: '#BAE6FD', rim: '#0C4A6E' },
    duel_champ: { outer: '#E11D48', inner: '#FECDD3', rim: '#881337' },
    collector: { outer: '#6366F1', inner: '#C7D2FE', rim: '#312E81' },
  };
  const c = palette[iconKey];

  return (
    <svg
      viewBox="0 0 60 60"
      className={`${className} shrink-0 ${unlocked ? '' : 'grayscale opacity-50'}`}
      aria-hidden="true"
    >
      {/* Shield / Medal Hexagon Base */}
      <path
        d="M30 4 L52 14 V31 C52 43 42 52 30 56 C18 52 8 43 8 31 V14 Z"
        fill={c.outer}
        stroke={c.rim}
        strokeWidth="3"
        strokeLinejoin="round"
      />
      <path
        d="M30 9 L47 17 V31 C47 40 39 47 30 50.5 C21 47 13 40 13 31 V17 Z"
        fill={c.inner}
        opacity="0.32"
      />
      <circle cx="30" cy="30" r="14" fill="#FFFFFF" opacity="0.25" />

      {iconKey === 'first_win' && (
        <path
          d="M30 15 L34.2 23.8 L44 25.2 L37 32 L38.6 41.6 L30 37 L21.4 41.6 L23 32 L16 25.2 L25.8 23.8 Z"
          fill="#FEF9C3"
          stroke={c.rim}
          strokeWidth="2"
          strokeLinejoin="round"
        />
      )}

      {iconKey === 'streak_5' && (
        <g>
          <path
            d="M31 14 C37 21 41 26 41 33 C41 40 36 45 30 45 C24 45 19 40 19 33 C19 28 22 23 26 20 C26 24 28 26 30 26 C30 21 30 17 31 14 Z"
            fill="#FEF08A"
            stroke={c.rim}
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <text x="30" y="39" textAnchor="middle" fontFamily="Fredoka, sans-serif" fontWeight="700" fontSize="11" fill={c.rim}>
            5×
          </text>
        </g>
      )}

      {iconKey === 'streak_10' && (
        <g>
          <path
            d="M17 34 L14 20 L24 26 L30 15 L36 26 L46 20 L43 34 Z"
            fill="#FACC15"
            stroke={c.rim}
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <rect x="17" y="34" width="26" height="9" rx="3" fill="#FEF9C3" stroke={c.rim} strokeWidth="2" />
          <text x="30" y="41.5" textAnchor="middle" fontFamily="Fredoka, sans-serif" fontWeight="700" fontSize="8.5" fill={c.rim}>
            10×
          </text>
        </g>
      )}

      {iconKey === 'spender_1000' && (
        <g>
          <polygon
            points="30,15 43,25 38,42 22,42 17,25"
            fill="#ECFDF5"
            stroke={c.rim}
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <polygon points="30,18 39,26 30,39 21,26" fill="#34D399" />
          <text x="30" y="31" textAnchor="middle" fontFamily="Fredoka, sans-serif" fontWeight="700" fontSize="9.5" fill="#064E3B">
            1K
          </text>
        </g>
      )}

      {iconKey === 'treasury_2000' && (
        <g>
          <circle cx="25" cy="32" r="9" fill="#FEF08A" stroke={c.rim} strokeWidth="2" />
          <circle cx="35" cy="27" r="9" fill="#FACC15" stroke={c.rim} strokeWidth="2" />
          <text x="35" y="30.5" textAnchor="middle" fontFamily="Fredoka, sans-serif" fontWeight="700" fontSize="9.5" fill={c.rim}>
            UZ
          </text>
        </g>
      )}

      {iconKey === 'circle_master' && (
        <g>
          <circle cx="30" cy="30" r="12" fill="none" stroke="#E0F2FE" strokeWidth="3.2" />
          <circle cx="30" cy="18" r="4" fill="#FACC15" stroke={c.rim} strokeWidth="1.5" />
          <circle cx="20" cy="36" r="4" fill="#34D399" stroke={c.rim} strokeWidth="1.5" />
          <circle cx="40" cy="36" r="4" fill="#FB7185" stroke={c.rim} strokeWidth="1.5" />
        </g>
      )}

      {iconKey === 'duel_champ' && (
        <g>
          <line x1="19" y1="40" x2="41" y2="18" stroke="#FFFFFF" strokeWidth="3.5" strokeLinecap="round" />
          <line x1="41" y1="40" x2="19" y2="18" stroke="#FEF08A" strokeWidth="3.5" strokeLinecap="round" />
          <circle cx="30" cy="29" r="5" fill="#FACC15" stroke={c.rim} strokeWidth="2" />
        </g>
      )}

      {iconKey === 'collector' && (
        <g>
          <rect x="18" y="18" width="12" height="12" rx="3" fill="#FDE047" stroke={c.rim} strokeWidth="1.8" />
          <rect x="28" y="24" width="12" height="12" rx="3" fill="#38BDF8" stroke={c.rim} strokeWidth="1.8" />
          <rect x="21" y="31" width="12" height="12" rx="3" fill="#F472B6" stroke={c.rim} strokeWidth="1.8" />
        </g>
      )}
    </svg>
  );
};

export const ShopDuelHubIcon: React.FC<{ className?: string }> = ({ className = 'w-16 h-16' }) => (
  <svg viewBox="0 0 64 64" className={`${className} shrink-0 drop-shadow`} aria-hidden="true">
    <defs>
      <linearGradient id="sdh_bg" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#F43F5E" />
        <stop offset="100%" stopColor="#9F1239" />
      </linearGradient>
    </defs>
    <rect x="4" y="4" width="56" height="56" rx="18" fill="url(#sdh_bg)" stroke="#FECDD3" strokeWidth="2.5" />
    <path d="M18 45 L44 19" stroke="#FFFFFF" strokeWidth="5" strokeLinecap="round" />
    <path d="M46 45 L20 19" stroke="#FDE047" strokeWidth="5" strokeLinecap="round" />
    <circle cx="32" cy="32" r="8" fill="#FACC15" stroke="#881337" strokeWidth="2.5" />
    <path d="M32 27 L33.8 30.8 L38 31.4 L35 34.2 L35.7 38.2 L32 36.2 L28.3 38.2 L29 34.2 L26 31.4 L30.2 30.8 Z" fill="#881337" />
  </svg>
);

export const ShopBoostersHubIcon: React.FC<{ className?: string }> = ({ className = 'w-16 h-16' }) => (
  <svg viewBox="0 0 64 64" className={`${className} shrink-0 drop-shadow`} aria-hidden="true">
    <defs>
      <linearGradient id="sbh_bg" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#FBBF24" />
        <stop offset="100%" stopColor="#D97706" />
      </linearGradient>
    </defs>
    <rect x="4" y="4" width="56" height="56" rx="18" fill="url(#sbh_bg)" stroke="#FEF08A" strokeWidth="2.5" />
    <path d="M32 14 C23 14 18 21 18 28 C18 33 21 37 24 40 L25 46 H39 L40 40 C43 37 46 33 46 28 C46 21 41 14 32 14 Z" fill="#FEF9C3" stroke="#92400E" strokeWidth="2.5" strokeLinejoin="round" />
    <rect x="26" y="47" width="12" height="5" rx="2.5" fill="#78350F" />
    <path d="M29 29 L33 22 L32 28 H36 L30 36 L31 30 Z" fill="#EA580C" />
  </svg>
);

export const ShopThemeHubIcon: React.FC<{ className?: string }> = ({ className = 'w-16 h-16' }) => (
  <svg viewBox="0 0 64 64" className={`${className} shrink-0 drop-shadow`} aria-hidden="true">
    <defs>
      <linearGradient id="sth_bg" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#38BDF8" />
        <stop offset="100%" stopColor="#1D4ED8" />
      </linearGradient>
    </defs>
    <rect x="4" y="4" width="56" height="56" rx="18" fill="url(#sth_bg)" stroke="#BAE6FD" strokeWidth="2.5" />
    <path
      d="M32 15 C20 15 13 24 13 33 C13 43 21 49 30 49 C34 49 36 47 36 44 C36 42 35 41 37 40 C40 39 50 40 50 31 C50 21 42 15 32 15 Z"
      fill="#FFFBEB"
      stroke="#1E3A8A"
      strokeWidth="2.5"
    />
    <circle cx="24" cy="28" r="4" fill="#EF4444" />
    <circle cx="34" cy="23" r="4" fill="#FACC15" />
    <circle cx="43" cy="29" r="3.8" fill="#10B981" />
    <circle cx="25" cy="39" r="3.8" fill="#8B5CF6" />
  </svg>
);

export const ShopAvatarHubIcon: React.FC<{ className?: string }> = ({ className = 'w-16 h-16' }) => (
  <svg viewBox="0 0 64 64" className={`${className} shrink-0 drop-shadow`} aria-hidden="true">
    <defs>
      <linearGradient id="sah_bg" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#34D399" />
        <stop offset="100%" stopColor="#047857" />
      </linearGradient>
    </defs>
    <rect x="4" y="4" width="56" height="56" rx="18" fill="url(#sah_bg)" stroke="#A7F3D0" strokeWidth="2.5" />
    <circle cx="32" cy="27" r="10" fill="#FEF3C7" stroke="#064E3B" strokeWidth="2.5" />
    <path d="M16 51 C16 40 48 40 48 51" fill="#FEF3C7" stroke="#064E3B" strokeWidth="2.5" strokeLinecap="round" />
    <path d="M22 18 L26 11 L32 15 L38 11 L42 18 Z" fill="#FACC15" stroke="#064E3B" strokeWidth="2" strokeLinejoin="round" />
  </svg>
);

export const BoosterHintIcon: React.FC<{ className?: string }> = ({ className = 'w-14 h-14' }) => (
  <svg viewBox="0 0 64 64" className={`${className} shrink-0 drop-shadow`} aria-hidden="true">
    <circle cx="32" cy="32" r="28" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="3" />
    <path d="M32 13 C23 13 18 20 18 27 C18 32 21 36 24 39 L25 45 H39 L40 39 C43 36 46 32 46 27 C46 20 41 13 32 13 Z" fill="#FBBF24" stroke="#92400E" strokeWidth="2.5" strokeLinejoin="round" />
    <rect x="26" y="46" width="12" height="5" rx="2.5" fill="#78350F" />
    <text x="32" y="32" textAnchor="middle" fontFamily="Fredoka, sans-serif" fontWeight="700" fontSize="14" fill="#78350F">
      A+
    </text>
  </svg>
);

export const BoosterSkipIcon: React.FC<{ className?: string }> = ({ className = 'w-14 h-14' }) => (
  <svg viewBox="0 0 64 64" className={`${className} shrink-0 drop-shadow`} aria-hidden="true">
    <circle cx="32" cy="32" r="28" fill="#E0F2FE" stroke="#0EA5E9" strokeWidth="3" />
    <polygon points="17,20 33,32 17,44" fill="#0284C7" stroke="#0C4A6E" strokeWidth="2.2" strokeLinejoin="round" />
    <polygon points="32,20 48,32 32,44" fill="#38BDF8" stroke="#0C4A6E" strokeWidth="2.2" strokeLinejoin="round" />
  </svg>
);

