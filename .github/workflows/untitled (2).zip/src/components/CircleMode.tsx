import React, { useMemo, useRef, useState } from 'react';
import { ArrowLeft, Lightbulb, Shuffle, Check, X, Sparkles } from 'lucide-react';
import { CIRCLE_LEVELS } from '../data/words';
import { PlayerProfile, VictoryReward } from '../types/game';
import { soundFx, triggerHaptic } from '../utils/sound';
import { UzcCoinIcon } from './GameIcons';
import { VictoryModal } from './VictoryModal';

interface CircleModeProps {
  profile: PlayerProfile;
  onBack: () => void;
  onUseHint: () => boolean;
  onFoundWord: (rewardUzc: number, rewardXp: number, isTargetWord: boolean) => void;
  onCompleteLevel: (nextLevel: number, bonusUzc: number, bonusXp: number) => void;
}

export const CircleMode: React.FC<CircleModeProps> = ({
  profile,
  onBack,
  onUseHint,
  onFoundWord,
  onCompleteLevel,
}) => {
  const levelIndex = (Math.max(1, profile.stats.circleLevel) - 1) % CIRCLE_LEVELS.length;
  const level = CIRCLE_LEVELS[levelIndex];

  const [wheelLetters, setWheelLetters] = useState<string[]>(() => [...level.letters]);
  const [foundTargets, setFoundTargets] = useState<string[]>([]);
  const [foundBonus, setFoundBonus] = useState<string[]>([]);
  const [revealedHints, setRevealedHints] = useState<Record<string, number[]>>({});
  const [selectedIndices, setSelectedIndices] = useState<number[]>([]);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [pointerPos, setPointerPos] = useState<{ x: number; y: number } | null>(null);
  const [toast, setToast] = useState<string>('');
  const [victoryReward, setVictoryReward] = useState<VictoryReward | null>(null);

  const wheelRef = useRef<HTMLDivElement | null>(null);
  const dragStartTimeRef = useRef<number>(0);
  const dragMovedRef = useRef<boolean>(false);

  const wheelSize = 236;
  const center = wheelSize / 2;
  const radius = 84;

  const nodePositions = useMemo(() => {
    const count = wheelLetters.length;
    return wheelLetters.map((letter, idx) => {
      const angle = (idx / count) * Math.PI * 2 - Math.PI / 2;
      return {
        idx,
        letter,
        x: center + Math.cos(angle) * radius,
        y: center + Math.sin(angle) * radius,
      };
    });
  }, [wheelLetters, center, radius]);

  const currentWord = selectedIndices.map((i) => wheelLetters[i]).join('');

  const showStatus = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast((prev) => (prev === msg ? '' : prev)), 2000);
  };

  const resetLevelState = (newLvlIdx: number) => {
    const nextLvl = CIRCLE_LEVELS[newLvlIdx % CIRCLE_LEVELS.length];
    setWheelLetters([...nextLvl.letters]);
    setFoundTargets([]);
    setFoundBonus([]);
    setRevealedHints({});
    setSelectedIndices([]);
    setVictoryReward(null);
  };

  const submitWord = (word: string) => {
    if (word.length < 3) {
      if (word.length > 0) showStatus('Kamida 4 harfli soʻz tuzing');
      return;
    }

    if (level.targets.includes(word)) {
      if (foundTargets.includes(word)) {
        soundFx.error(profile.settings.sound);
        showStatus('Bu soʻz allaqachon topilgan');
        return;
      }
      const nextFound = [...foundTargets, word];
      setFoundTargets(nextFound);
      soundFx.match(profile.settings.sound);
      triggerHaptic(profile.settings.vibration, 25);
      onFoundWord(15, 15, true);
      showStatus(`Ajoyib! +15 UZC (${word})`);

      if (nextFound.length === level.targets.length) {
        const nextLevelNum = profile.stats.circleLevel + 1;
        setTimeout(() => {
          soundFx.victory(profile.settings.sound);
          onCompleteLevel(nextLevelNum, 90, 75);
          setVictoryReward({
            titleUz: 'Bosqich Yakunlandi!',
            subtitleUz: `"${level.titleUz}" bosqichidagi barcha ${level.targets.length} ta soʻz topildi!`,
            uzc: 90,
            xp: 75,
            isWin: true,
          });
        }, 420);
      }
      return;
    }

    if (level.bonus.includes(word)) {
      if (foundBonus.includes(word)) {
        showStatus('Bonus soʻz allaqachon topilgan');
        return;
      }
      setFoundBonus((prev) => [...prev, word]);
      soundFx.coin(profile.settings.sound);
      onFoundWord(8, 8, false);
      showStatus(`Bonus soʻz! +8 UZC (${word})`);
      return;
    }

    soundFx.error(profile.settings.sound);
    showStatus('Roʻyxatda bunday soʻz yoʻq');
  };

  const getLocalCoords = (clientX: number, clientY: number) => {
    const rect = wheelRef.current?.getBoundingClientRect();
    if (!rect) return null;
    return {
      x: clientX - rect.left,
      y: clientY - rect.top,
    };
  };

  const findHitNode = (x: number, y: number): number | null => {
    for (const node of nodePositions) {
      const dx = x - node.x;
      const dy = y - node.y;
      if (dx * dx + dy * dy <= 28 * 28) {
        return node.idx;
      }
    }
    return null;
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    const pt = getLocalCoords(e.clientX, e.clientY);
    if (!pt) return;
    const hit = findHitNode(pt.x, pt.y);
    if (hit === null) return;

    e.currentTarget.setPointerCapture(e.pointerId);
    dragStartTimeRef.current = Date.now();
    dragMovedRef.current = false;
    setIsDragging(true);
    setPointerPos(pt);

    if (selectedIndices.includes(hit)) {
      // Allow tapping an already-tapped node to remove if it's the last one
      if (selectedIndices[selectedIndices.length - 1] === hit) {
        setSelectedIndices((prev) => prev.slice(0, -1));
      }
      return;
    }

    soundFx.key(profile.settings.sound);
    triggerHaptic(profile.settings.vibration, 10);
    setSelectedIndices((prev) => [...prev, hit]);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const pt = getLocalCoords(e.clientX, e.clientY);
    if (!pt) return;
    setPointerPos(pt);

    const hit = findHitNode(pt.x, pt.y);
    if (hit !== null && !selectedIndices.includes(hit)) {
      dragMovedRef.current = true;
      soundFx.key(profile.settings.sound);
      triggerHaptic(profile.settings.vibration, 10);
      setSelectedIndices((prev) => [...prev, hit]);
    }
  };

  const handlePointerUp = () => {
    if (!isDragging) return;
    setIsDragging(false);
    setPointerPos(null);

    // If user dragged across >= 2 letters, submit immediately on release
    if (dragMovedRef.current && selectedIndices.length >= 2) {
      submitWord(currentWord);
      setSelectedIndices([]);
    }
  };

  const handleShuffle = () => {
    soundFx.flip(profile.settings.sound, 0);
    setWheelLetters((prev) => {
      const copy = [...prev];
      for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
      }
      return copy;
    });
    setSelectedIndices([]);
  };

  const handleHint = () => {
    const unsolved = level.targets.filter((w) => !foundTargets.includes(w));
    if (unsolved.length === 0) return;

    // Pick first unsolved word with unrevealed letter
    for (const word of unsolved) {
      const revealed = revealedHints[word] || [];
      const hiddenIndices = word
        .split('')
        .map((_, idx) => idx)
        .filter((idx) => !revealed.includes(idx));

      if (hiddenIndices.length > 0) {
        if (!onUseHint()) {
          showStatus('Maslahat tugagan! Doʻkondan UZC ga oling');
          return;
        }
        const pick = hiddenIndices[Math.floor(Math.random() * hiddenIndices.length)];
        soundFx.coin(profile.settings.sound);
        setRevealedHints((prev) => ({
          ...prev,
          [word]: [...(prev[word] || []), pick],
        }));
        showStatus(`"${word.length} harfli" soʻzda harf ochildi!`);
        return;
      }
    }
    showStatus('Barcha maslahat harflari ochilgan');
  };

  return (
    <div className="min-h-screen w-full flex flex-col bg-gradient-to-b from-cyan-600 via-sky-700 to-blue-900 dark:from-slate-900 dark:via-slate-950 dark:to-black text-white">
      <header className="w-full max-w-2xl mx-auto px-4 pt-4 pb-2 flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          aria-label="Orqaga"
          className="w-11 h-11 rounded-2xl bg-black/20 hover:bg-black/30 flex items-center justify-center cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="text-center">
          <h1 className="font-display font-bold text-xl tracking-wide">
            CIRCLE · {profile.stats.circleLevel}-BOSQICH
          </h1>
          <p className="text-xs text-cyan-100/90">
            {level.titleUz} · 4–10 harfli soʻzlar
          </p>
        </div>

        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/25 border border-white/20">
          <UzcCoinIcon className="w-4 h-4" />
          <span className="font-mono-num text-sm font-bold text-amber-300">{profile.uzc}</span>
        </div>
      </header>

      <main className="flex-1 w-full max-w-2xl mx-auto px-4 pb-6 flex flex-col items-center justify-between gap-4">
        {/* Target words grid */}
        <div className="w-full rounded-3xl bg-black/20 border border-white/15 p-3.5 sm:p-4">
          <div className="flex items-center justify-between text-xs text-cyan-100 mb-2.5">
            <span className="font-semibold">
              Topilgan soʻzlar: {foundTargets.length}/{level.targets.length}
            </span>
            <span className="inline-flex items-center gap-1 text-amber-200 font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              Bonus: {foundBonus.length}
            </span>
          </div>

          <div className="flex flex-wrap gap-2 justify-center">
            {level.targets.map((word) => {
              const isFound = foundTargets.includes(word);
              const hintCols = revealedHints[word] || [];
              return (
                <div
                  key={word}
                  className="flex gap-1 bg-slate-950/35 px-2 py-1.5 rounded-xl border border-white/10"
                >
                  {word.split('').map((ch, idx) => {
                    const showChar = isFound || hintCols.includes(idx);
                    return (
                      <span
                        key={idx}
                        className={`w-6 h-7 rounded-md flex items-center justify-center font-display font-bold text-sm ${
                          isFound
                            ? 'bg-emerald-500 text-white'
                            : showChar
                            ? 'bg-amber-400/30 text-amber-200 border border-amber-300/50'
                            : 'bg-white/10 text-transparent'
                        }`}
                      >
                        {showChar ? ch : '_'}
                      </span>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>

        {/* Toast & Active Word Preview */}
        <div className="flex flex-col items-center gap-1.5 min-h-[56px] justify-center">
          {toast && (
            <div className="px-4 py-1 rounded-xl bg-slate-950/85 border border-amber-300/40 text-amber-200 text-xs font-bold">
              {toast}
            </div>
          )}
          <div className="flex items-center gap-2">
            <div className="min-w-[140px] h-11 px-4 rounded-2xl bg-white/15 border border-white/25 flex items-center justify-center font-display font-bold text-2xl tracking-widest">
              {currentWord || <span className="text-xs font-sans text-cyan-100/70 tracking-normal">Harflarni ulang</span>}
            </div>
            {currentWord.length > 0 && (
              <>
                <button
                  type="button"
                  onClick={() => {
                    submitWord(currentWord);
                    setSelectedIndices([]);
                  }}
                  aria-label="Tekshirish"
                  className="w-11 h-11 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center border-b-4 border-emerald-700 cursor-pointer"
                >
                  <Check className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedIndices([])}
                  aria-label="Tozalash"
                  className="w-11 h-11 rounded-2xl bg-rose-500 hover:bg-rose-400 text-white flex items-center justify-center border-b-4 border-rose-700 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Circular Wheel */}
        <div
          ref={wheelRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          style={{ width: wheelSize, height: wheelSize, touchAction: 'none' }}
          className="relative rounded-full bg-white/15 border-4 border-white/30 shadow-2xl select-none shrink-0"
        >
          {/* SVG connecting line */}
          <svg
            width={wheelSize}
            height={wheelSize}
            className="absolute inset-0 pointer-events-none"
          >
            {selectedIndices.length > 0 && (
              <polyline
                fill="none"
                stroke="#FDE047"
                strokeWidth="8"
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity="0.85"
                points={[
                  ...selectedIndices.map((idx) => {
                    const p = nodePositions[idx];
                    return `${p.x},${p.y}`;
                  }),
                  ...(isDragging && pointerPos ? [`${pointerPos.x},${pointerPos.y}`] : []),
                ].join(' ')}
              />
            )}
          </svg>

          {/* Center label */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-14 h-14 rounded-full bg-white/15 border border-white/25 flex items-center justify-center font-display font-bold text-xs text-cyan-50 text-center">
              {wheelLetters.length} harf
            </div>
          </div>

          {/* Letter Nodes */}
          {nodePositions.map((node) => {
            const isSelected = selectedIndices.includes(node.idx);
            return (
              <div
                key={node.idx}
                style={{
                  left: node.x - 26,
                  top: node.y - 26,
                  width: 52,
                  height: 52,
                }}
                className={`absolute rounded-full flex items-center justify-center font-display font-bold text-2xl transition-transform pointer-events-none ${
                  isSelected
                    ? 'bg-amber-400 text-amber-950 scale-110 border-2 border-white shadow-lg'
                    : 'bg-white text-sky-900 border-b-4 border-sky-200 shadow-md'
                }`}
              >
                {node.letter}
              </div>
            );
          })}
        </div>

        {/* Bottom Controls */}
        <div className="w-full flex items-center justify-between gap-4 pt-1">
          <button
            type="button"
            onClick={handleHint}
            className="px-5 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-bold text-sm border-b-4 border-amber-600 flex items-center gap-2 cursor-pointer"
          >
            <Lightbulb className="w-5 h-5" />
            Maslahat ({profile.hints})
          </button>

          <p className="text-xs text-cyan-100/85 text-center hidden sm:block">
            Harflardan soʻzlar tuzing (tortib yoki bosib)
          </p>

          <button
            type="button"
            onClick={handleShuffle}
            className="px-5 py-3 rounded-2xl bg-white/20 hover:bg-white/30 text-white font-bold text-sm border-b-4 border-sky-900 flex items-center gap-2 cursor-pointer"
          >
            <Shuffle className="w-5 h-5" />
            Aralashtirish
          </button>
        </div>
      </main>

      <VictoryModal
        reward={victoryReward}
        onContinue={() => {
          resetLevelState(profile.stats.circleLevel - 1);
          onBack();
        }}
        onPlayAgain={() => {
          resetLevelState(profile.stats.circleLevel - 1);
        }}
      />
    </div>
  );
};
