import React, { useState } from 'react';
import { BarChart3, ChevronRight, Plus, Volume2, VolumeX } from 'lucide-react';
import { getTodayDateKey } from '../data/words';
import { getActiveTaskDefinitions, xpNeededForLevel } from '../services/playerService';
import { GameView, PlayerProfile } from '../types/game';
import {
  CircleModeIcon,
  ClassicModeIcon,
  DailyModeIcon,
  MixedModeIcon,
  PlayerAvatarSvg,
  SettingsNavIcon,
  ShopNavIcon,
  TasksNavIcon,
  TogetherModeIcon,
  UzcCoinIcon,
  WordyCrownLogo,
} from './GameIcons';

interface HomeShellProps {
  profile: PlayerProfile;
  onSelectMode: (mode: GameView) => void;
  onOpenShop: () => void;
  onOpenStats: () => void;
  onOpenSettings: () => void;
  onOpenTasks: () => void;
  onOpenProfile: () => void;
  onToggleSound: () => void;
}

import backdropImg from '../assets/images/wordy_backdrop_sky_1794729740274.jpg';

const BACKDROP_IMG = backdropImg;

export const HomeShell: React.FC<HomeShellProps> = ({
  profile,
  onSelectMode,
  onOpenShop,
  onOpenStats,
  onOpenSettings,
  onOpenTasks,
  onOpenProfile,
  onToggleSound,
}) => {
  const [bgErr, setBgErr] = useState(false);
  const today = getTodayDateKey();
  const solvedSet = new Set(profile.dailyState.solvedIndices);

  const claimableTasksCount = getActiveTaskDefinitions().filter((t) => {
    const state = profile.tasks[t.id];
    return state && state.progress >= t.target && !state.claimed;
  }).length;

  const shopBadgeCount = profile.lastFreeCoinDate !== today ? 1 : 0;

  const neededXp = xpNeededForLevel(profile.level);
  const xpPct = Math.min(100, Math.round((profile.xp / neededXp) * 100));

  const effectiveTheme = profile.settings.blueTheme ? 'blue' : profile.activeTheme;

  const hubGradient =
    effectiveTheme === 'blue'
      ? 'from-sky-500 via-blue-600 to-indigo-700 border-sky-200/50'
      : effectiveTheme === 'emerald'
      ? 'from-emerald-500 via-teal-600 to-green-800 border-emerald-200/50'
      : 'from-orange-500 via-amber-500 to-orange-600 border-amber-200/60';

  return (
    <div className="relative min-h-[100dvh] w-full flex items-center justify-center p-2.5 sm:p-5 md:p-6 overflow-x-hidden bg-gradient-to-b from-indigo-950 via-purple-950 to-slate-950 dark:from-slate-950 dark:via-slate-900 dark:to-black text-white">
      {/* Full-viewport atmospheric game backdrop */}
      {!bgErr && (
        <img
          src={BACKDROP_IMG}
          alt=""
          aria-hidden="true"
          referrerPolicy="no-referrer"
          onError={() => setBgErr(true)}
          className="absolute inset-0 w-full h-full object-cover opacity-55 dark:opacity-30 pointer-events-none select-none"
        />
      )}
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-gradient-to-b from-slate-950/25 via-transparent to-slate-950/60 pointer-events-none"
      />

      {/* Responsive Game Shell adapting seamlessly to mobile & tablet */}
      <main
        className={`relative z-10 w-full max-w-[440px] sm:max-w-[500px] rounded-[28px] sm:rounded-[32px] bg-gradient-to-b ${hubGradient} border-2 shadow-[0_24px_60px_rgba(0,0,0,0.55)] p-3.5 sm:p-5 flex flex-col gap-3`}
      >
        {/* Top Profile & UZC Bar */}
        <header className="flex items-center justify-between gap-2 bg-black/22 rounded-2xl px-3 py-2 border border-white/15">
          <button
            type="button"
            onClick={onOpenProfile}
            title="Profil va yutuqlar"
            className="flex items-center gap-2.5 min-w-0 text-left cursor-pointer group"
          >
            <div className="shrink-0 group-hover:scale-105 transition-transform">
              <PlayerAvatarSvg avatarId={profile.avatarId} className="w-10 h-10 sm:w-11 sm:h-11" />
            </div>
            <div className="min-w-0">
              <div className="font-display font-bold text-sm sm:text-base leading-tight truncate group-hover:text-amber-200 transition-colors">
                {profile.displayName}
              </div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="font-mono-num text-[11px] font-bold text-amber-200 whitespace-nowrap">
                  Daraja {profile.level}
                </span>
                <div className="w-14 sm:w-20 h-1.5 rounded-full bg-black/40 overflow-hidden">
                  <div
                    style={{ width: `${xpPct}%` }}
                    className="h-full bg-amber-300 rounded-full"
                  />
                </div>
              </div>
            </div>
          </button>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={onOpenShop}
              className="flex items-center gap-1.5 pl-2.5 pr-1.5 py-1.5 rounded-xl bg-black/35 hover:bg-black/45 border border-amber-300/40 transition-colors cursor-pointer shrink-0"
            >
              <UzcCoinIcon className="w-5 h-5" />
              <span className="font-mono-num font-bold text-xs sm:text-sm text-amber-200">
                {profile.uzc} UZC
              </span>
              <span className="w-5 h-5 rounded-lg bg-emerald-500 text-white flex items-center justify-center">
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
              </span>
            </button>

            <button
              type="button"
              onClick={onToggleSound}
              aria-label={profile.settings.sound ? 'Ovozni oʻchirish' : 'Ovozni yoqish'}
              title={profile.settings.sound ? 'Ovoz: Yoqilgan' : 'Ovoz: Oʻchirilgan'}
              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl border flex items-center justify-center transition-colors cursor-pointer shrink-0 ${
                profile.settings.sound
                  ? 'bg-black/35 hover:bg-black/45 border-white/25 text-white'
                  : 'bg-rose-500/80 hover:bg-rose-500 border-rose-200/50 text-white'
              }`}
            >
              {profile.settings.sound ? (
                <Volume2 className="w-4 h-4 sm:w-5 sm:h-5" />
              ) : (
                <VolumeX className="w-4 h-4 sm:w-5 sm:h-5" />
              )}
            </button>
          </div>
        </header>

        {/* WORDY Crown Logo */}
        <div className="py-0.5 flex justify-center">
          <WordyCrownLogo size="md" />
        </div>

        {/* Strict Mode Order:
            Row 1: Classic (full width)
            Row 2: Daily (full width)
            Row 3: Mixed | Circle (2-column side-by-side row)
            Row 4: Together (full width)
        */}
        <div className="grid grid-cols-2 gap-2.5">
          {/* 1. CLASSIC */}
          <button
            type="button"
            onClick={() => onSelectMode('CLASSIC')}
            className="col-span-2 rounded-2xl bg-gradient-to-b from-amber-50 to-amber-200 hover:from-white hover:to-amber-100 text-amber-950 px-3.5 sm:px-4 py-2.5 sm:py-3 border-b-4 border-amber-500 flex items-center justify-between shadow-md active:translate-y-0.5 transition-transform cursor-pointer"
          >
            <div className="flex items-center gap-3 sm:gap-3.5">
              <ClassicModeIcon className="w-10 h-10 sm:w-11 sm:h-11 shrink-0" />
              <div className="text-left">
                <div className="font-display font-bold text-base sm:text-lg leading-tight">
                  CLASSIC
                </div>
                <div className="text-xs font-semibold text-amber-900/75">
                  5 yoki 6 harfli Wordle
                </div>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-amber-800 shrink-0" />
          </button>

          {/* 2. DAILY */}
          <button
            type="button"
            onClick={() => onSelectMode('DAILY')}
            className="col-span-2 rounded-2xl bg-gradient-to-b from-amber-50 to-amber-200 hover:from-white hover:to-amber-100 text-amber-950 px-3.5 sm:px-4 py-2.5 sm:py-3 border-b-4 border-amber-500 flex items-center justify-between shadow-md active:translate-y-0.5 transition-transform cursor-pointer"
          >
            <div className="flex items-center gap-3 sm:gap-3.5">
              <DailyModeIcon className="w-10 h-10 sm:w-11 sm:h-11 shrink-0" />
              <div className="text-left">
                <div className="font-display font-bold text-base sm:text-lg leading-tight">
                  DAILY
                </div>
                <div className="text-xs font-semibold text-amber-900/75">
                  Kunlik 5 ta soʻz · {solvedSet.size}/5
                </div>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-amber-800 shrink-0" />
          </button>

          {/* 3a. MIXED (left) */}
          <button
            type="button"
            onClick={() => onSelectMode('MIXED')}
            className="col-span-1 rounded-2xl bg-gradient-to-b from-amber-50 to-amber-200 hover:from-white hover:to-amber-100 text-amber-950 px-3 py-2.5 sm:py-3 border-b-4 border-amber-500 flex items-center gap-2.5 shadow-md active:translate-y-0.5 transition-transform cursor-pointer min-w-0"
          >
            <MixedModeIcon className="w-9 h-9 sm:w-10 sm:h-10 shrink-0" />
            <div className="text-left min-w-0">
              <div className="font-display font-bold text-sm sm:text-base leading-tight truncate">
                MIXED
              </div>
              <div className="text-[11px] sm:text-xs font-semibold text-amber-900/75 truncate">
                Chalkash soʻzlar
              </div>
            </div>
          </button>

          {/* 3b. CIRCLE (right) */}
          <button
            type="button"
            onClick={() => onSelectMode('CIRCLE')}
            className="col-span-1 rounded-2xl bg-gradient-to-b from-amber-50 to-amber-200 hover:from-white hover:to-amber-100 text-amber-950 px-3 py-2.5 sm:py-3 border-b-4 border-amber-500 flex items-center gap-2.5 shadow-md active:translate-y-0.5 transition-transform cursor-pointer min-w-0"
          >
            <CircleModeIcon className="w-9 h-9 sm:w-10 sm:h-10 shrink-0" />
            <div className="text-left min-w-0">
              <div className="font-display font-bold text-sm sm:text-base leading-tight truncate">
                CIRCLE
              </div>
              <div className="text-[11px] sm:text-xs font-semibold text-amber-900/75 truncate">
                4–10 harf
              </div>
            </div>
          </button>

          {/* 4. TOGETHER */}
          <button
            type="button"
            onClick={() => onSelectMode('TOGETHER')}
            className="col-span-2 rounded-2xl bg-gradient-to-b from-cyan-300 to-sky-400 hover:from-cyan-200 hover:to-sky-300 text-sky-950 px-3.5 sm:px-4 py-2.5 sm:py-3 border-b-4 border-sky-700 flex items-center justify-between shadow-md active:translate-y-0.5 transition-transform cursor-pointer"
          >
            <div className="flex items-center gap-3 sm:gap-3.5">
              <TogetherModeIcon className="w-10 h-10 sm:w-11 sm:h-11 shrink-0" />
              <div className="text-left">
                <div className="font-display font-bold text-base sm:text-lg leading-tight">
                  TOGETHER
                </div>
                <div className="text-xs font-bold text-sky-950/80">
                  Doʻst bilan duel
                </div>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-sky-950 shrink-0" />
          </button>
        </div>

        {/* Bottom Navigation Bar (4 dedicated actions including Statistika) */}
        <nav className="grid grid-cols-4 gap-2 pt-1.5 border-t border-black/15">
          <button
            type="button"
            onClick={onOpenShop}
            className="relative rounded-2xl bg-black/22 hover:bg-black/32 py-2 px-1 flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors"
          >
            {shopBadgeCount > 0 && (
              <span className="absolute -top-1 right-2 w-5 h-5 rounded-full bg-rose-500 border-2 border-white text-[10px] font-bold flex items-center justify-center shadow">
                {shopBadgeCount}
              </span>
            )}
            <ShopNavIcon className="w-7 h-7 sm:w-8 sm:h-8" />
            <span className="text-[11px] sm:text-xs font-bold leading-tight">Doʻkon</span>
          </button>

          <button
            type="button"
            onClick={onOpenStats}
            className="rounded-2xl bg-black/22 hover:bg-black/32 py-2 px-1 flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors"
          >
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-gradient-to-b from-sky-400 to-indigo-600 border border-white/30 flex items-center justify-center shadow-sm">
              <BarChart3 className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
            </div>
            <span className="text-[11px] sm:text-xs font-bold leading-tight">Statistika</span>
          </button>

          <button
            type="button"
            onClick={onOpenTasks}
            className="relative rounded-2xl bg-black/22 hover:bg-black/32 py-2 px-1 flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors"
          >
            {claimableTasksCount > 0 && (
              <span className="absolute -top-1 right-2 w-5 h-5 rounded-full bg-rose-500 border-2 border-white text-[10px] font-bold flex items-center justify-center shadow">
                {claimableTasksCount}
              </span>
            )}
            <TasksNavIcon className="w-7 h-7 sm:w-8 sm:h-8" />
            <span className="text-[11px] sm:text-xs font-bold leading-tight">Topshiriqlar</span>
          </button>

          <button
            type="button"
            onClick={onOpenSettings}
            className="rounded-2xl bg-black/22 hover:bg-black/32 py-2 px-1 flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors"
          >
            <SettingsNavIcon className="w-7 h-7 sm:w-8 sm:h-8" />
            <span className="text-[11px] sm:text-xs font-bold leading-tight">Sozlamalar</span>
          </button>
        </nav>
      </main>
    </div>
  );
};
