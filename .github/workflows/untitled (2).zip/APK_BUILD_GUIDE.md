# WORDY.apk — PC’siz (faqat telefon bilan) GitHub orqali APK yasash qoʻllanmasi

Loyiha **`.github/workflows/build.yml`** orqali yuklangan `.zip` faylni **avtomatik oʻzi ochib**, Capacitor Android loyihasidan **`WORDY.apk`** yigʻadigan qilib sozlangan.

## 1-qadam: AI Studio’dan ZIP yuklab olish
1. AI Studio’dan loyihani **Download ZIP** qilib telefoningizga yuklab oling (arxivni ochish shart emas!).

## 2-qadam: GitHub repository va `build.yml` ni bir marta sozlash
1. Telefonda brauzerdan [github.com](https://github.com) ga kiring → **New repository** bosing:
   - Nomi: masalan `wordy-apk`
   - **Add a README file** katakchasini yoqing → **Create repository** bosing.
2. Repository ichida **Add file → Create new file** ni bosing:
   - Fayl nomini aynan shunday yozing: `.github/workflows/build.yml`
   - Ushbu loyihadagi `.github/workflows/build.yml` matnini koʻchirib joylashtiring va **Commit changes** bosing.

## 3-qadam: ZIP faylni yuklash va APK olish
1. Repository bosh sahifasida **Add file → Upload files** ni bosing.
2. Telefoningizdagi yuklab olingan `.zip` faylni tanlang (nomi istalgancha boʻlishi mumkin, masalan `wordy.zip`) va **Commit changes** bosing.
3. **Actions** boʻlimiga kiring — `Build WORDY.apk (Auto ZIP + Capacitor)` jarayoni ZIP’ni avtomatik ochib, 2–3 daqiqada yashil ✅ boʻladi.
4. Tayyor **`WORDY.apk`** ni olish uchun repository sahifasidagi **Releases** boʻlimiga kiring va **`WORDY.apk`** ustiga bosib telefoningizga yuklab oʻrnating!

*(Keyingi safar ilovani yangilaganingizda yana AI Studio’dan yangi ZIP yuklab olib, GitHub’ga **Add file → Upload files** orqali tashlasangiz bas — yana avtomatik yangi **`WORDY.apk`** yigʻiladi.)*
