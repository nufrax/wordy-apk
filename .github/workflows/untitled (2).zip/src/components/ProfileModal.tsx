import React from 'react';
import { Award, CheckCircle2, Flame, Lock, Palette, TrendingUp, X } from 'lucide-react';
import { ACHIEVEMENT_BADGES, xpNeededForLevel } from '../services/playerService';
import { PlayerProfile } from '../types/game';
import { ActivityStreakGrid } from './ActivityStreakGrid';
import { AchievementBadgeIcon, PlayerAvatarSvg, UzcCoinIcon } from './GameIcons';

interface ProfileModalProps {
  open: boolean;
  profile: PlayerProfile;
  onClose: () => void;
  onOpenAvatarShop: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  open,
  profile,
  onClose,
  onOpenAvatarShop,
}) => {
  if (!open) return null;

  const neededXp = xpNeededForLevel(profile.level);
  const xpPct = Math.min(100, Math.round((profile.xp / neededXp) * 100));
  const unlockedCount = ACHIEVEMENT_BADGES.filter((b) => profile.tasks[b.id]?.claimed).length;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-xl max-h-[90vh] flex flex-col rounded-3xl bg-gradient-to-b from-amber-50 to-orange-100 dark:from-slate-900 dark:to-slate-950 text-slate-900 dark:text-slate-100 border-2 border-amber-400/70 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="shrink-0 px-5 py-4 bg-gradient-to-r from-indigo-600 via-violet-600 to-purple-600 text-white flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <PlayerAvatarSvg avatarId={profile.avatarId} className="w-12 h-12 sm:w-14 sm:h-14" />
            <div className="min-w-0">
              <h2 className="font-display font-bold text-lg sm:text-xl leading-tight truncate">
                {profile.displayName}
              </h2>
              <div className="flex items-center gap-2 mt-1">
                <span className="font-mono-num text-xs font-bold text-amber-200 whitespace-nowrap">
                  Daraja {profile.level}
                </span>
                <div className="w-20 sm:w-28 h-2 rounded-full bg-black/35 overflow-hidden">
                  <div
                    style={{ width: `${xpPct}%` }}
                    className="h-full bg-amber-300 rounded-full"
                  />
                </div>
                <span className="font-mono-num text-[11px] text-indigo-100">
                  {profile.xp}/{neededXp} XP
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenAvatarShop();
              }}
              className="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 border border-white/25 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Palette className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Avatarlar</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Yopish"
              className="w-9 h-9 rounded-xl bg-black/25 hover:bg-black/35 flex items-center justify-center cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 min-h-0 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Career Summary Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="rounded-2xl bg-white dark:bg-slate-800 border border-amber-200 dark:border-slate-700 p-3 shadow-sm">
              <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                Joriy balans
              </div>
              <div className="mt-1 flex items-center gap-1.5 font-mono-num font-bold text-base text-amber-600 dark:text-amber-300">
                <UzcCoinIcon className="w-4 h-4 shrink-0" />
                {profile.uzc}
              </div>
            </div>

            <div className="rounded-2xl bg-white dark:bg-slate-800 border border-amber-200 dark:border-slate-700 p-3 shadow-sm">
              <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                Jami topilgan
              </div>
              <div className="mt-1 flex items-center gap-1.5 font-mono-num font-bold text-base text-emerald-600 dark:text-emerald-400">
                <TrendingUp className="w-4 h-4 shrink-0" />
                {profile.stats.totalUzcEarned}
              </div>
            </div>

            <div className="rounded-2xl bg-white dark:bg-slate-800 border border-amber-200 dark:border-slate-700 p-3 shadow-sm">
              <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                Sarflangan UZC
              </div>
              <div className="mt-1 font-mono-num font-bold text-base text-sky-600 dark:text-sky-400">
                {profile.stats.totalUzcSpent} UZC
              </div>
            </div>

            <div className="rounded-2xl bg-white dark:bg-slate-800 border border-amber-200 dark:border-slate-700 p-3 shadow-sm">
              <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                Gʻalaba rekordi
              </div>
              <div className="mt-1 flex items-center gap-1 font-mono-num font-bold text-base text-orange-600 dark:text-orange-400">
                <Flame className="w-4 h-4 shrink-0" />
                {profile.stats.bestWinStreak} ta
              </div>
            </div>
          </div>

          {/* 30-Day Activity Streak Squares Grid */}
          <ActivityStreakGrid activityDays={profile.dailyState?.activityDays} />

          {/* Achievements / Badges Section */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-violet-600 dark:text-violet-400" />
                <h3 className="font-display font-bold text-base sm:text-lg">
                  YUTUQLAR VA NISHONLAR
                </h3>
              </div>
              <span className="font-mono-num text-xs font-bold px-2.5 py-1 rounded-lg bg-violet-100 dark:bg-violet-900/50 text-violet-700 dark:text-violet-300 border border-violet-300/70 dark:border-violet-700">
                {unlockedCount} / {ACHIEVEMENT_BADGES.length}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {ACHIEVEMENT_BADGES.map((badge) => {
                const taskState = profile.tasks[badge.id];
                const isUnlocked = Boolean(taskState?.claimed);
                const currentVal = Math.min(badge.target, Math.max(0, badge.metric(profile)));
                const pct = Math.round((currentVal / badge.target) * 100);

                return (
                  <div
                    key={badge.id}
                    className={`rounded-2xl p-3 border-2 flex items-start gap-3 transition-colors ${
                      isUnlocked
                        ? 'bg-white dark:bg-slate-800 border-amber-400/80 dark:border-amber-500/60 shadow-sm'
                        : 'bg-white/65 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700/80'
                    }`}
                  >
                    <div className="relative shrink-0">
                      <AchievementBadgeIcon
                        iconKey={badge.iconKey}
                        unlocked={isUnlocked}
                        className="w-12 h-12"
                      />
                      {!isUnlocked && (
                        <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-slate-700 text-white border-2 border-white flex items-center justify-center">
                          <Lock className="w-2.5 h-2.5" />
                        </span>
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-1.5">
                        <div className="font-bold text-xs sm:text-sm leading-snug">
                          {badge.titleUz}
                        </div>
                        {isUnlocked ? (
                          <span className="shrink-0 inline-flex items-center gap-0.5 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          </span>
                        ) : null}
                      </div>

                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-snug">
                        {badge.descUz}
                      </p>

                      <div className="flex items-center justify-between gap-2 mt-2">
                        <div className="flex-1 h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                          <div
                            style={{ width: `${isUnlocked ? 100 : pct}%` }}
                            className={`h-full rounded-full ${
                              isUnlocked ? 'bg-emerald-500' : 'bg-amber-500'
                            }`}
                          />
                        </div>
                        <span className="font-mono-num text-[10px] font-bold text-slate-600 dark:text-slate-300 shrink-0">
                          {isUnlocked ? badge.target : currentVal}/{badge.target}
                        </span>
                      </div>

                      <div className="mt-1.5 flex items-center gap-1 text-[11px] font-bold text-amber-600 dark:text-amber-300">
                        <UzcCoinIcon className="w-3.5 h-3.5" />
                        <span className="font-mono-num">
                          +{badge.rewardUzc} UZC {isUnlocked ? '· Olindi' : ''}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
