import React, { useState } from 'react';
import {
  ArrowLeft,
  Check,
  Clock,
  Gift,
  Sparkles,
  UserCheck,
  X,
  Zap,
} from 'lucide-react';
import { getTodayDateKey } from '../data/words';
import { SHOP_ITEMS, ShopItem } from '../services/playerService';
import { AvatarId, PlayerProfile, ThemeId } from '../types/game';
import {
  BoosterHintIcon,
  BoosterSkipIcon,
  PlayerAvatarSvg,
  ShopAvatarHubIcon,
  ShopBoostersHubIcon,
  ShopDuelHubIcon,
  ShopThemeHubIcon,
  UzcCoinIcon,
} from './GameIcons';

interface ShopModalProps {
  open: boolean;
  profile: PlayerProfile;
  initialTab?: 'all' | 'hints' | 'powerups' | 'themes' | 'avatars';
  onClose: () => void;
  onClaimFreeCoins: () => void;
  onBuyItem: (item: ShopItem) => void;
  onEquipTheme: (themeId: ThemeId) => void;
  onEquipAvatar: (avatarId: AvatarId) => void;
}

type ShopSection = 'hub' | 'powerups' | 'hints' | 'themes' | 'avatars';

const SECTION_TITLES: Record<ShopSection, string> = {
  hub: 'DOʻKON',
  powerups: 'DUEL KUCHLARI',
  hints: 'BOOSTERS',
  themes: 'MAVZULAR',
  avatars: 'AVATARLAR',
};

const THEME_PREVIEW_STYLES: Record<ThemeId, { swatch: string; badge: string }> = {
  sunset: {
    swatch: 'from-orange-500 via-amber-500 to-orange-600',
    badge: 'Quyoshli oltin',
  },
  blue: {
    swatch: 'from-sky-500 via-blue-600 to-indigo-700',
    badge: 'Moviy okean',
  },
  emerald: {
    swatch: 'from-emerald-500 via-teal-600 to-green-800',
    badge: 'Zumrad oʻrmon',
  },
};

export const ShopModal: React.FC<ShopModalProps> = ({
  open,
  profile,
  initialTab = 'all',
  onClose,
  onClaimFreeCoins,
  onBuyItem,
  onEquipTheme,
  onEquipAvatar,
}) => {
  const [section, setSection] = useState<ShopSection>(
    initialTab === 'all' ? 'hub' : initialTab
  );

  React.useEffect(() => {
    if (open) {
      setSection(initialTab === 'all' ? 'hub' : initialTab);
    }
  }, [open, initialTab]);

  if (!open) return null;

  const today = getTodayDateKey();
  const freeAvailable = profile.lastFreeCoinDate !== today;

  const boosterItems = SHOP_ITEMS.filter((i) => i.category === 'hints');
  const duelItems = SHOP_ITEMS.filter((i) => i.category === 'powerups');
  const themeItems = SHOP_ITEMS.filter((i) => i.category === 'themes');
  const avatarItems = SHOP_ITEMS.filter((i) => i.category === 'avatars');

  const renderPriceButton = (item: ShopItem) => {
    const canAfford = profile.uzc >= item.priceUzc;
    return (
      <button
        type="button"
        disabled={!canAfford}
        onClick={() => onBuyItem(item)}
        className={`w-full py-2.5 px-3 rounded-2xl font-display font-bold text-sm flex items-center justify-center gap-1.5 border-b-4 transition-transform active:translate-y-0.5 ${
          canAfford
            ? 'bg-gradient-to-b from-amber-300 to-amber-500 hover:from-amber-200 hover:to-amber-400 text-amber-950 border-amber-700 cursor-pointer shadow'
            : 'bg-slate-200 dark:bg-slate-700 text-slate-400 border-slate-300 dark:border-slate-800 cursor-not-allowed'
        }`}
      >
        <UzcCoinIcon className="w-4 h-4 shrink-0" />
        <span className="font-mono-num">{item.priceUzc} UZC</span>
      </button>
    );
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-lg max-h-[90vh] flex flex-col rounded-3xl bg-gradient-to-b from-amber-50 to-orange-100 dark:from-slate-900 dark:to-slate-950 text-slate-900 dark:text-slate-100 border-2 border-amber-400/75 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="shrink-0 px-4 sm:px-5 py-3.5 bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 text-white flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            {section !== 'hub' && (
              <button
                type="button"
                onClick={() => setSection('hub')}
                aria-label="Orqaga"
                className="w-9 h-9 rounded-xl bg-black/20 hover:bg-black/30 flex items-center justify-center cursor-pointer shrink-0"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <div className="min-w-0">
              <h2 className="font-display font-bold text-lg sm:text-xl leading-none truncate">
                {SECTION_TITLES[section]}
              </h2>
              <div className="flex items-center gap-1.5 mt-1 text-xs text-amber-100 font-mono-num font-bold">
                <UzcCoinIcon className="w-4 h-4 shrink-0" />
                <span>{profile.uzc} UZC</span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Yopish"
            className="w-9 h-9 rounded-xl bg-black/20 hover:bg-black/30 flex items-center justify-center cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 min-h-0 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* ==================== HUB: 4 BIG CATEGORY ICONS ==================== */}
          {section === 'hub' && (
            <>
              {/* Daily Free Gift Card */}
              <div className="rounded-2xl bg-gradient-to-r from-amber-300 via-yellow-300 to-amber-400 text-amber-950 p-3.5 flex items-center justify-between gap-3 border-b-4 border-amber-600 shadow-sm">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-11 h-11 rounded-xl bg-white/55 flex items-center justify-center shrink-0">
                    <Gift className="w-6 h-6 text-rose-600" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-display font-bold text-base leading-tight">
                      Kunlik sovgʻa
                    </div>
                    <div className="text-xs font-bold text-amber-900/80">
                      Har kuni +50 UZC
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  disabled={!freeAvailable}
                  onClick={onClaimFreeCoins}
                  className={`px-4 py-2 rounded-xl font-display font-bold text-xs whitespace-nowrap shrink-0 border-b-2 ${
                    freeAvailable
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-white border-emerald-700 cursor-pointer shadow'
                      : 'bg-amber-950/20 text-amber-900/60 border-transparent cursor-default'
                  }`}
                >
                  {freeAvailable ? 'Olish (+50)' : 'Olingan'}
                </button>
              </div>

              {/* 4 Big Glossy Category Cards */}
              <div className="grid grid-cols-2 gap-3.5">
                <button
                  type="button"
                  onClick={() => setSection('powerups')}
                  className="rounded-3xl bg-gradient-to-b from-rose-500 to-rose-700 hover:from-rose-400 hover:to-rose-600 text-white p-5 border-b-[5px] border-rose-900 shadow-lg flex flex-col items-center justify-center gap-3 active:translate-y-0.5 transition-transform cursor-pointer"
                >
                  <ShopDuelHubIcon className="w-16 h-16 sm:w-20 sm:h-20" />
                  <span className="font-display font-bold text-lg sm:text-xl tracking-wide">
                    DUEL
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setSection('hints')}
                  className="rounded-3xl bg-gradient-to-b from-amber-400 to-orange-600 hover:from-amber-300 hover:to-orange-500 text-white p-5 border-b-[5px] border-orange-800 shadow-lg flex flex-col items-center justify-center gap-3 active:translate-y-0.5 transition-transform cursor-pointer"
                >
                  <ShopBoostersHubIcon className="w-16 h-16 sm:w-20 sm:h-20" />
                  <span className="font-display font-bold text-lg sm:text-xl tracking-wide">
                    BOOSTERS
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setSection('themes')}
                  className="rounded-3xl bg-gradient-to-b from-sky-400 to-blue-700 hover:from-sky-300 hover:to-blue-600 text-white p-5 border-b-[5px] border-blue-900 shadow-lg flex flex-col items-center justify-center gap-3 active:translate-y-0.5 transition-transform cursor-pointer"
                >
                  <ShopThemeHubIcon className="w-16 h-16 sm:w-20 sm:h-20" />
                  <span className="font-display font-bold text-lg sm:text-xl tracking-wide">
                    THEME
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setSection('avatars')}
                  className="rounded-3xl bg-gradient-to-b from-emerald-400 to-teal-700 hover:from-emerald-300 hover:to-teal-600 text-white p-5 border-b-[5px] border-teal-900 shadow-lg flex flex-col items-center justify-center gap-3 active:translate-y-0.5 transition-transform cursor-pointer"
                >
                  <ShopAvatarHubIcon className="w-16 h-16 sm:w-20 sm:h-20" />
                  <span className="font-display font-bold text-lg sm:text-xl tracking-wide">
                    AVATAR
                  </span>
                </button>
              </div>
            </>
          )}

          {/* ==================== SUBVIEW 1: BOOSTERS (WORDLE STYLE) ==================== */}
          {section === 'hints' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2.5">
                <div className="rounded-2xl bg-white dark:bg-slate-800 border-2 border-amber-200 dark:border-slate-700 px-3 py-2 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    Maslahatlar:
                  </span>
                  <span className="font-mono-num font-bold text-sm text-amber-600 dark:text-amber-300">
                    {profile.hints} ta
                  </span>
                </div>
                <div className="rounded-2xl bg-white dark:bg-slate-800 border-2 border-sky-200 dark:border-slate-700 px-3 py-2 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    Oʻtkazish:
                  </span>
                  <span className="font-mono-num font-bold text-sm text-sky-600 dark:text-sky-300">
                    {profile.powerups.skipWord || 0} ta
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {boosterItems.map((item) => {
                  const isSkip = item.powerupKey === 'skipWord';
                  return (
                    <div
                      key={item.id}
                      className="rounded-3xl bg-white dark:bg-slate-800 border-2 border-amber-200 dark:border-slate-700 p-4 flex flex-col items-center text-center justify-between gap-3 shadow-md"
                    >
                      <div className="flex flex-col items-center gap-2">
                        {isSkip ? (
                          <BoosterSkipIcon className="w-16 h-16" />
                        ) : (
                          <BoosterHintIcon className="w-16 h-16" />
                        )}
                        <div className="font-display font-bold text-base leading-tight">
                          {item.titleUz}
                        </div>
                      </div>
                      {renderPriceButton(item)}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ==================== SUBVIEW 2: DUEL BOOSTERS ==================== */}
          {section === 'powerups' && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {duelItems.map((item) => {
                const ownedCount = item.powerupKey ? profile.powerups[item.powerupKey] || 0 : 0;
                const icon =
                  item.powerupKey === 'revealLetter' ? (
                    <Sparkles className="w-9 h-9 text-amber-500" />
                  ) : item.powerupKey === 'freezeTime' ? (
                    <Clock className="w-9 h-9 text-sky-500" />
                  ) : (
                    <Zap className="w-9 h-9 text-rose-500" />
                  );
                const bg =
                  item.powerupKey === 'revealLetter'
                    ? 'bg-amber-100 dark:bg-amber-500/20 border-amber-300'
                    : item.powerupKey === 'freezeTime'
                    ? 'bg-sky-100 dark:bg-sky-500/20 border-sky-300'
                    : 'bg-rose-100 dark:bg-rose-500/20 border-rose-300';

                return (
                  <div
                    key={item.id}
                    className="rounded-3xl bg-white dark:bg-slate-800 border-2 border-rose-200 dark:border-slate-700 p-4 flex flex-col items-center text-center justify-between gap-3 shadow-md"
                  >
                    <span className="font-mono-num text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-200">
                      Zaxira: {ownedCount}
                    </span>
                    <div className={`w-16 h-16 rounded-2xl border-2 flex items-center justify-center ${bg}`}>
                      {icon}
                    </div>
                    <div>
                      <div className="font-display font-bold text-sm leading-tight">
                        {item.titleUz}
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                        {item.descUz}
                      </p>
                    </div>
                    {renderPriceButton(item)}
                  </div>
                );
              })}
            </div>
          )}

          {/* ==================== SUBVIEW 3: THEMES ==================== */}
          {section === 'themes' && (
            <div className="grid grid-cols-1 gap-3.5">
              {themeItems.map((item) => {
                const themeId = item.themeId || 'blue';
                const owned = profile.ownedThemes.includes(themeId);
                const active = profile.activeTheme === themeId;
                const preview = THEME_PREVIEW_STYLES[themeId];

                return (
                  <div
                    key={item.id}
                    className="rounded-3xl bg-white dark:bg-slate-800 border-2 border-sky-200 dark:border-slate-700 overflow-hidden shadow-md"
                  >
                    <div
                      className={`h-20 w-full bg-gradient-to-r ${preview.swatch} p-4 flex items-end justify-between text-white`}
                    >
                      <span className="font-display font-bold text-lg drop-shadow">
                        {item.titleUz}
                      </span>
                      <span className="text-xs font-bold px-2.5 py-1 rounded-xl bg-black/30">
                        {preview.badge}
                      </span>
                    </div>
                    <div className="p-4 flex items-center justify-between gap-3">
                      <p className="text-xs font-medium text-slate-600 dark:text-slate-300">
                        {item.descUz}
                      </p>
                      <div className="w-36 shrink-0">
                        {owned ? (
                          <button
                            type="button"
                            disabled={active}
                            onClick={() => onEquipTheme(themeId)}
                            className={`w-full py-2.5 px-3 rounded-2xl font-display font-bold text-xs flex items-center justify-center gap-1.5 border-b-4 ${
                              active
                                ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 border-emerald-300'
                                : 'bg-sky-500 hover:bg-sky-400 text-white border-sky-700 cursor-pointer'
                            }`}
                          >
                            {active ? <Check className="w-4 h-4" /> : null}
                            {active ? 'Faol' : 'Tanlash'}
                          </button>
                        ) : (
                          renderPriceButton(item)
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* ==================== SUBVIEW 4: AVATARS ==================== */}
          {section === 'avatars' && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {avatarItems.map((item) => {
                const avatarId = item.avatarId || 'boy_blue';
                const owned = profile.ownedAvatars.includes(avatarId);
                const active = profile.avatarId === avatarId;

                return (
                  <div
                    key={item.id}
                    className={`rounded-3xl bg-white dark:bg-slate-800 border-2 p-3.5 flex flex-col items-center text-center justify-between gap-2.5 shadow-md ${
                      active
                        ? 'border-emerald-400 dark:border-emerald-500'
                        : 'border-amber-200 dark:border-slate-700'
                    }`}
                  >
                    <PlayerAvatarSvg avatarId={avatarId} className="w-16 h-16 drop-shadow" />
                    <div>
                      <div className="font-display font-bold text-xs sm:text-sm leading-tight">
                        {item.titleUz}
                      </div>
                    </div>
                    {owned ? (
                      <button
                        type="button"
                        disabled={active}
                        onClick={() => onEquipAvatar(avatarId)}
                        className={`w-full py-2 px-2 rounded-2xl font-display font-bold text-xs flex items-center justify-center gap-1 border-b-4 ${
                          active
                            ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 border-emerald-300'
                            : 'bg-sky-500 hover:bg-sky-400 text-white border-sky-700 cursor-pointer'
                        }`}
                      >
                        {active ? <UserCheck className="w-3.5 h-3.5" /> : null}
                        {active ? 'Tanlangan' : 'Kiyish'}
                      </button>
                    ) : (
                      renderPriceButton(item)
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
