import React, { useState } from 'react';
import { Trophy, RotateCcw, ArrowRight } from 'lucide-react';
import { VictoryReward } from '../types/game';
import { UzcCoinIcon } from './GameIcons';

interface VictoryModalProps {
  reward: VictoryReward | null;
  onContinue: () => void;
  onPlayAgain?: () => void;
}

import trophyGoldCupImg from '../assets/images/trophy_gold_cup_1794729743149.jpg';

const TROPHY_IMG = trophyGoldCupImg;

export const VictoryModal: React.FC<VictoryModalProps> = ({
  reward,
  onContinue,
  onPlayAgain,
}) => {
  const [imgErr, setImgErr] = useState(false);

  if (!reward) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative w-full max-w-sm rounded-3xl bg-gradient-to-b from-indigo-900 via-indigo-950 to-slate-950 border-2 border-amber-400/60 p-5 text-center shadow-2xl animate-wordy-pop">
        {/* Trophy illustration centerpiece */}
        <div className="mx-auto mb-3 w-24 h-24 rounded-full overflow-hidden border-3 border-amber-400 shadow-[0_0_24px_rgba(250,204,21,0.35)] bg-indigo-950 flex items-center justify-center">
          {!imgErr ? (
            <img
              src={TROPHY_IMG}
              alt="Gʻalaba kubogi"
              referrerPolicy="no-referrer"
              onError={() => setImgErr(true)}
              className="w-full h-full object-cover"
            />
          ) : (
            <Trophy
              className={`w-12 h-12 ${reward.isWin ? 'text-amber-400' : 'text-slate-300'}`}
              strokeWidth={2}
            />
          )}
        </div>

        {/* Ribbon banner */}
        <div className="inline-block px-6 py-1.5 rounded-xl bg-gradient-to-r from-rose-600 via-rose-500 to-rose-600 border-b-4 border-rose-800 shadow-lg mb-2.5">
          <h2 className="font-display font-bold text-xl sm:text-2xl text-white tracking-wide">
            {reward.titleUz}
          </h2>
        </div>

        <p className="text-xs sm:text-sm text-indigo-100/90 mb-4 leading-relaxed">
          {reward.subtitleUz}
        </p>

        {/* UZC + XP Reward readout */}
        <div className="flex items-center justify-center gap-3 mb-5">
          {reward.uzc > 0 && (
            <div className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-amber-500/15 border border-amber-400/40">
              <span className="font-mono-num font-bold text-xl text-amber-300">
                +{reward.uzc}
              </span>
              <UzcCoinIcon className="w-6 h-6" />
              <span className="text-xs font-bold text-amber-200">UZC</span>
            </div>
          )}
          {reward.xp > 0 && (
            <div className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-sky-500/15 border border-sky-400/35">
              <span className="font-mono-num font-bold text-lg text-sky-300">
                +{reward.xp}
              </span>
              <span className="text-xs font-bold text-sky-200">XP</span>
            </div>
          )}
        </div>

        <div className="flex flex-col sm:flex-row gap-2.5">
          {onPlayAgain && (
            <button
              type="button"
              onClick={onPlayAgain}
              className="flex-1 py-2.5 px-4 rounded-2xl bg-indigo-700 hover:bg-indigo-600 text-white font-bold text-sm border-b-4 border-indigo-900 active:translate-y-0.5 transition-transform flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-4 h-4" />
              Yana oʻynash
            </button>
          )}
          <button
            type="button"
            onClick={onContinue}
            className="flex-1 py-2.5 px-5 rounded-2xl bg-gradient-to-b from-amber-300 to-amber-500 hover:from-amber-200 hover:to-amber-400 text-amber-950 font-display font-bold text-base border-b-4 border-amber-700 active:translate-y-0.5 transition-transform flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            Davom etish
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
